# ARC Launcher

Tauri 2 + React launcher for ARC (Fortnite 4.2).

Original launcher design: this launcher is UNFINISHED, credit me if used.

## Run / build

```
npm install
npm run tauri dev      # dev
npm run tauri build    # installer in src-tauri/target/release/bundle
```

Needs Rust + the Tauri 2 prerequisites (Visual Studio Build Tools + WebView2 on Windows).

## What it talks to

Backend: `http://15.204.255.118:3551` (`src/api/launcherService.ts` → `BACKEND_URL`).

- Sign in: **Continue with Discord** → `/api/launcher/discord/start` → browser → `/discord/poll`.
  New players pick a username in the launcher (`/discord/register`), or run `/register` in the ARC Discord first — same account either way.
- Home: greeting, equipped skin (`/active-skin`), V-Bucks (`/vbucks`), patch notes (`/patchnotes`).
- Shop: live item shop (`/itemshop`), owned check (`/owned`), buy with V-Bucks (`/buy`).
- Play: `launch_fortnite` (Rust, `src-tauri/src/launch.rs`).

## Launch chain (`src-tauri/src/launch.rs`)

This is the v5.53 ARC launch chain, unchanged: downloads the hook DLL from `DLL_URL`
(cached in `%APPDATA%/ARC-Launcher/hook.dll`), installs the sprint-by-default pak, writes the
FakeAC stub, starts `FortniteClient-Win64-Shipping.exe` suspended with
`-AUTH_LOGIN/-AUTH_PASSWORD -AUTH_TYPE=epic -epicapp=Fortnite ... -noeac -fromfl=eac -fltoken=...`,
injects the DLL, resumes. `DLL_URL` / `FL_TOKEN` / pak URLs are the constants at the top of the file.

## Backend setup for Discord sign-in

In the Discord Developer Portal → your app → OAuth2 → Redirects, add exactly:

```
http://15.204.255.118:3551/api/launcher/discord/callback
```

and in the backend `.env`: `DISCORD_OAUTH_CLIENT_ID`, `DISCORD_OAUTH_CLIENT_SECRET`, `DISCORD_OAUTH_REDIRECT` (same URL).
