Put the soundtrack audio files here.

  christmas-battle-bus.mp3   <- "Fortnite - Christmas Battle Bus Music (Chapter 2)"

The launcher plays /soundtracks/<id>.mp3 - add more in src/soundtracks.ts.
