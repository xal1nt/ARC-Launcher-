mod builds;
mod fortnite;
mod launch;
mod rpc;

use launch::LaunchArgs;

#[tauri::command]
async fn launch_build(args: LaunchArgs) -> Result<u32, String> {
    launch::launch_build(args).await
}

#[tauri::command]
async fn inspect_build(path: String) -> Result<launch::BuildInspection, String> {
    tauri::async_runtime::spawn_blocking(move || launch::inspect_build(&path))
        .await
        .map_err(|e| e.to_string())
}

#[tauri::command]
async fn rpc_update(skin_url: Option<String>, skin_name: Option<String>, player_name: Option<String>, in_game: bool) {
    tauri::async_runtime::spawn_blocking(move || rpc::update(skin_url, skin_name, player_name, in_game)).await.ok();
}

#[tauri::command]
async fn rpc_clear() {
    tauri::async_runtime::spawn_blocking(rpc::clear).await.ok();
}

#[tauri::command]
fn is_fortnite_running() -> bool {
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        let out = std::process::Command::new("tasklist")
            .args(["/FI", "IMAGENAME eq FortniteClient-Win64-Shipping.exe", "/NH"])
            .creation_flags(0x0800_0000)
            .output();
        if let Ok(o) = out {
            return String::from_utf8_lossy(&o.stdout).contains("FortniteClient-Win64-Shipping.exe");
        }
    }
    false
}

#[tauri::command]
fn close_fortnite() -> bool {
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        for exe in ["FortniteClient-Win64-Shipping.exe", "FortniteClient-Win64-Shipping_EAC.exe", "FortniteClient-Win64-Shipping_BE.exe", "FortniteLauncher.exe"] {
            let _ = std::process::Command::new("taskkill").args(["/IM", exe, "/F"]).creation_flags(0x0800_0000).output();
        }
    }
    true
}

#[tauri::command]
fn greet(name: &str) -> String {
    format!("Hello, {}! You've been greeted from Rust!", name)
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_dialog::init())
        .invoke_handler(tauri::generate_handler![
            greet,
            fortnite::validate_build_folder,
            fortnite::verify_build_integrity,
            fortnite::detect_build_version,
            launch_build,
            inspect_build,
            is_fortnite_running,
            close_fortnite,
            rpc_update,
            rpc_clear,
            builds::download_build,
            builds::cancel_build_download
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
