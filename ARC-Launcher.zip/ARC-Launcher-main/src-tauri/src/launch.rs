use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

const DLL_URL: &str =
    "https://raw.githubusercontent.com/dr3sogfn/asdasas/refs/heads/main/Paradise.dll";
const FL_TOKEN: &str = "h1cdhchd10150221h130eB56";
const COMMON_ARGS: &str =
    "-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -skippatchcheck";

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum AntiCheat {
    None,
    Eac,
    Be,
}

#[derive(Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct LaunchArgs {
    pub fortnite_path: String,
    pub email: String,
    pub password: String,
    #[serde(default)]
    pub account_id: String,
    #[serde(default)]
    pub bubble: bool,
}

fn win64_dir(fortnite_path: &str) -> PathBuf {
    Path::new(fortnite_path)
        .join("FortniteGame")
        .join("Binaries")
        .join("Win64")
}

pub fn detect_anticheat(fortnite_path: &str) -> AntiCheat {
    let w = win64_dir(fortnite_path);
    let has_be = w.join("FortniteClient-Win64-Shipping_BE.exe").exists();
    let has_eac = w.join("FortniteClient-Win64-Shipping_EAC.exe").exists();
    if has_be {
        AntiCheat::Be
    } else if has_eac {
        AntiCheat::Eac
    } else {
        AntiCheat::None
    }
}

#[allow(dead_code)]
fn ac_exe_name(ac: AntiCheat) -> &'static str {
    match ac {
        AntiCheat::Be => "FortniteClient-Win64-Shipping_BE.exe",
        AntiCheat::Eac => "FortniteClient-Win64-Shipping_EAC.exe",
        AntiCheat::None => "",
    }
}

fn build_args(ac: AntiCheat) -> String {
    match ac {
        AntiCheat::Be => format!("{COMMON_ARGS} -nobe  -fromfl=be  -fltoken={FL_TOKEN}"),
        AntiCheat::Eac => format!("{COMMON_ARGS} -noeac -fromfl=eac -fltoken={FL_TOKEN}"),
        AntiCheat::None => format!("{COMMON_ARGS} -fltoken={FL_TOKEN}"),
    }
}

fn cache_dir() -> PathBuf {
    dirs::config_dir()
        .unwrap_or_else(|| PathBuf::from("."))
        .join("ARC-Launcher")
}
fn hook_dll_path() -> PathBuf {
    cache_dir().join("hook.dll")
}
fn local_appdata() -> PathBuf {
    dirs::data_local_dir().unwrap_or_else(|| PathBuf::from("."))
}
fn stub_dir() -> PathBuf {
    local_appdata().join("ARC").join("FakeAC")
}
fn stub_path() -> PathBuf {
    stub_dir().join("stub.exe")
}

fn ensure_config_bootstrap() {
    let base = local_appdata().join("FortniteGame").join("Saved");
    let config_dir = base.join("Config").join("WindowsClient");
    let _ = std::fs::create_dir_all(&config_dir);

    let gus = config_dir.join("GameUserSettings.ini");
    if !gus.exists() {
        let _ = std::fs::write(
            &gus,
            "[/Script/FortniteGame.FortGameUserSettings]\r\n\r\n\
             [/Script/Engine.GameUserSettings]\r\n\r\n\
             [ScalabilityGroups]\r\n\r\n",
        );
    }
    for f in ["Engine.ini", "Game.ini"] {
        let p = config_dir.join(f);
        if !p.exists() {
            let _ = std::fs::write(&p, "");
        }
    }
    let _ = std::fs::create_dir_all(base.join("Logs"));
    let _ = std::fs::create_dir_all(base.join("Crashes"));
}

fn generate_minimal_stub() -> Vec<u8> {
    let mut pe = vec![0u8; 1024];

    pe[0] = 0x4D;
    pe[1] = 0x5A;
    pe[0x3c] = 0x80;

    let nt: &[u8] = &[
        0x50, 0x45, 0x00, 0x00,
        0x64, 0x86,
        0x01, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0xF0, 0x00,
        0x22, 0x00,
        0x0B, 0x02,
        0x0E, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x10, 0x00, 0x00,
        0x00, 0x10, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x40,
        0x01, 0x00, 0x00, 0x00,
        0x00, 0x10, 0x00, 0x00,
        0x00, 0x02, 0x00, 0x00,
        0x06, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00,
        0x06, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00,
        0x00, 0x20, 0x00, 0x00,
        0x00, 0x02, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00,
        0x02, 0x00,
        0x00, 0x00,
        0x00, 0x00, 0x10, 0x00,
        0x00, 0x00, 0x00, 0x00,
        0x00, 0x10, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x10, 0x00,
        0x00, 0x00, 0x00, 0x00,
        0x00, 0x10, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00,
        0x10, 0x00, 0x00, 0x00,
    ];
    pe[0x80..0x80 + nt.len()].copy_from_slice(nt);

    let opt_start = 0x80 + 4 + 20;
    let sec_hdr = opt_start + 240;
    pe[sec_hdr] = 0x2E;
    pe[sec_hdr + 1] = 0x74;
    pe[sec_hdr + 2] = 0x65;
    pe[sec_hdr + 3] = 0x78;
    pe[sec_hdr + 4] = 0x74;
    pe[sec_hdr + 8] = 0x10;
    pe[sec_hdr + 12] = 0x00;
    pe[sec_hdr + 13] = 0x10;
    pe[sec_hdr + 16] = 0x00;
    pe[sec_hdr + 17] = 0x02;
    pe[sec_hdr + 20] = 0x00;
    pe[sec_hdr + 21] = 0x02;
    pe[sec_hdr + 36] = 0x20;
    pe[sec_hdr + 39] = 0x60;

    let code: &[u8] = &[
        0x48, 0xC7, 0xC1, 0xFF, 0xFF, 0xFF, 0xFF,
        0x31, 0xD2,
        0xB8, 0x2C, 0x00, 0x00, 0x00,
        0x0F, 0x05,
        0xC3,
    ];
    pe[0x200..0x200 + code.len()].copy_from_slice(code);

    pe
}

fn ensure_stub() {
    let _ = std::fs::create_dir_all(stub_dir());
    let sp = stub_path();
    if !sp.exists() {
        let _ = std::fs::write(&sp, generate_minimal_stub());
    }
}

async fn refresh_hook_dll() -> bool {
    let _ = std::fs::create_dir_all(cache_dir());
    let dst = hook_dll_path();
    match reqwest::Client::new().get(DLL_URL).send().await {
        Ok(resp) if resp.status().is_success() => match resp.bytes().await {
            Ok(bytes) => {
                let tmp = dst.with_extension("part");
                if std::fs::write(&tmp, &bytes).is_ok() && std::fs::rename(&tmp, &dst).is_ok() {
                    true
                } else {
                    dst.exists()
                }
            }
            Err(_) => dst.exists(),
        },
        _ => dst.exists(),
    }
}

const SPRINT_PAK_NAME: &str = "pakchunkSprintByDefault-WindowsClient.pak";
const SPRINT_SIG_NAME: &str = "pakchunkSprintByDefault-WindowsClient.sig";
const SPRINT_PAK_URL: &str =
    "https://raw.githubusercontent.com/xal1nt/sadadsasdadsad/refs/heads/main/pakchunkSprintByDefault-WindowsClient.pak";
const SPRINT_SIG_URL: &str =
    "https://raw.githubusercontent.com/xal1nt/asdasdasdsad/refs/heads/main/pakchunkSprintByDefault-WindowsClient.sig";

fn paks_cache_dir() -> PathBuf {
    dirs::config_dir()
        .unwrap_or_else(|| PathBuf::from("."))
        .join("ARC")
        .join("Paks")
}
fn file_len(p: &Path) -> u64 {
    std::fs::metadata(p).map(|m| m.len()).unwrap_or(0)
}
async fn download_to(url: &str, dst: &Path) -> bool {
    match reqwest::Client::new().get(url).send().await {
        Ok(r) if r.status().is_success() => match r.bytes().await {
            Ok(b) => std::fs::write(dst, &b).is_ok(),
            Err(_) => false,
        },
        _ => false,
    }
}

async fn ensure_sprint_pak(fortnite_path: &str) -> bool {
    let paks = Path::new(fortnite_path)
        .join("FortniteGame")
        .join("Content")
        .join("Paks");
    if !paks.is_dir() {
        return false;
    }
    let cache = paks_cache_dir();
    let _ = std::fs::create_dir_all(&cache);
    let cached_pak = cache.join(SPRINT_PAK_NAME);
    let cached_sig = cache.join(SPRINT_SIG_NAME);
    let marker = cache.join("sprint.src");
    let source = format!("{SPRINT_PAK_URL}\n{SPRINT_SIG_URL}");
    let fresh = std::fs::read_to_string(&marker).unwrap_or_default() != source;
    if fresh {
        let _ = std::fs::remove_file(&cached_pak);
        let _ = std::fs::remove_file(&cached_sig);
    }

    if !cached_pak.exists() || file_len(&cached_pak) == 0 {
        download_to(SPRINT_PAK_URL, &cached_pak).await;
    }
    if !cached_sig.exists() || file_len(&cached_sig) == 0 {
        download_to(SPRINT_SIG_URL, &cached_sig).await;
    }
    if file_len(&cached_pak) == 0 || file_len(&cached_sig) == 0 {
        return false;
    }
    if fresh {
        let _ = std::fs::write(&marker, &source);
    }

    let dest_pak = paks.join(SPRINT_PAK_NAME);
    let dest_sig = paks.join(SPRINT_SIG_NAME);
    if fresh || !dest_pak.exists() || file_len(&dest_pak) != file_len(&cached_pak) {
        let _ = std::fs::copy(&cached_pak, &dest_pak);
    }
    if fresh || !dest_sig.exists() || file_len(&dest_sig) != file_len(&cached_sig) {
        let _ = std::fs::copy(&cached_sig, &dest_sig);
    }
    true
}

fn patch_queue_text(exe: &Path) {
    use std::io::{Seek, SeekFrom, Write};
    const HEAD: &str = "Finding match...";
    let needle: Vec<u8> = format!("{HEAD}\nPlayers in Queue: {{0}}")
        .encode_utf16()
        .flat_map(|c| c.to_le_bytes())
        .collect();
    let Ok(data) = std::fs::read(exe) else { return };
    let Some(pos) = data.windows(needle.len()).position(|w| w == needle.as_slice()) else { return };
    let cut = (pos + HEAD.encode_utf16().count() * 2) as u64;
    drop(data);
    if let Ok(mut f) = std::fs::OpenOptions::new().write(true).open(exe) {
        if f.seek(SeekFrom::Start(cut)).is_ok() {
            let _ = f.write_all(&[0u8, 0u8]);
        }
    }
}

pub async fn launch_build(a: LaunchArgs) -> Result<u32, String> {
    if a.email.is_empty() || a.password.is_empty() {
        return Err("Missing ARC account credentials. Sign in again.".into());
    }
    let shipping = win64_dir(&a.fortnite_path).join("FortniteClient-Win64-Shipping.exe");
    if !shipping.exists() {
        return Err("FortniteClient-Win64-Shipping.exe not found in this install path.".into());
    }

    let ac = detect_anticheat(&a.fortnite_path);
    if ac == AntiCheat::None {
        return Err(
            "Couldn't find FortniteClient-Win64-Shipping_BE.exe or _EAC.exe. The Fortnite folder looks incomplete."
                .into(),
        );
    }
    let args = build_args(ac);

    ensure_config_bootstrap();

    if !refresh_hook_dll().await {
        return Err("Hook DLL unavailable and no cached copy. Check your connection and try again.".into());
    }

    let _ = ensure_sprint_pak(&a.fortnite_path).await;

    ensure_stub();

    patch_queue_text(&shipping);

    std::env::set_var("OPENSSL_ia32cap", "~0x20000000");

    let full_args = format!(
        "-AUTH_LOGIN={} -AUTH_PASSWORD={} -AUTH_TYPE=epic {}",
        a.email, a.password, args
    );

    platform::launch(
        shipping.to_string_lossy().to_string(),
        full_args,
        hook_dll_path().to_string_lossy().to_string(),
        ac,
    )
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BuildInspection {
    pub fortnite_game: bool,
    pub engine: bool,
    pub shipping: bool,
    pub anticheat: String,
    pub version: String,
    pub build: String,
    pub splash: Option<String>,
}

pub fn read_splash_data_url(path: &str) -> Option<String> {
    use base64::Engine;
    let dir = Path::new(path)
        .join("FortniteGame")
        .join("Content")
        .join("Splash");
    if !dir.is_dir() {
        return None;
    }
    let preferred = [
        "Splash.bmp", "Splash.png", "splash.bmp", "splash.png", "Splash.jpg", "Splash.jpeg",
    ];
    let mut chosen: Option<PathBuf> = None;
    for name in preferred {
        let p = dir.join(name);
        if p.is_file() {
            chosen = Some(p);
            break;
        }
    }
    if chosen.is_none() {
        if let Ok(rd) = std::fs::read_dir(&dir) {
            for e in rd.flatten() {
                let p = e.path();
                if let Some(ext) = p.extension().and_then(|s| s.to_str()) {
                    let ext = ext.to_lowercase();
                    if ["bmp", "png", "jpg", "jpeg"].contains(&ext.as_str()) {
                        chosen = Some(p);
                        break;
                    }
                }
            }
        }
    }
    let p = chosen?;
    let meta = std::fs::metadata(&p).ok()?;
    if meta.len() > 16 * 1024 * 1024 {
        return None;
    }
    let bytes = std::fs::read(&p).ok()?;
    let ext = p.extension().and_then(|s| s.to_str()).unwrap_or("bmp").to_lowercase();
    let mime = match ext.as_str() {
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        _ => "image/bmp",
    };
    Some(format!(
        "data:{};base64,{}",
        mime,
        base64::engine::general_purpose::STANDARD.encode(&bytes)
    ))
}

fn byte_find(hay: &[u8], needle: &[u8]) -> Option<usize> {
    if needle.is_empty() || hay.len() < needle.len() {
        return None;
    }
    let first = needle[0];
    let last = hay.len() - needle.len();
    let mut i = 0;
    while i <= last {
        if hay[i] == first && &hay[i..i + needle.len()] == needle {
            return Some(i);
        }
        i += 1;
    }
    None
}

fn is_ver_char(b: u8) -> bool {
    b.is_ascii_alphanumeric() || b == b'.' || b == b'-' || b == b'+'
}

fn parse_version(raw: &str) -> (String, String) {
    let parts: Vec<&str> = raw.split('-').collect();
    let version_raw = parts.first().copied().unwrap_or("");
    let version = version_raw.split('+').next().unwrap_or(version_raw).to_string();
    if let Some(cl_idx) = parts.iter().position(|p| p.eq_ignore_ascii_case("CL")) {
        if let Some(cl_num) = parts.get(cl_idx + 1) {
            return (version.clone(), format!("{}-CL-{}", version, cl_num));
        }
    }
    (version.clone(), version)
}

fn scan_version(exe: &Path) -> (String, String) {
    let data = match std::fs::read(exe) {
        Ok(d) => d,
        Err(_) => return (String::new(), String::new()),
    };
    let ascii = b"++Fortnite+Release-";
    if let Some(pos) = byte_find(&data, ascii) {
        let mut s = String::new();
        let mut i = pos + ascii.len();
        while i < data.len() && is_ver_char(data[i]) && s.len() < 48 {
            s.push(data[i] as char);
            i += 1;
        }
        if !s.is_empty() {
            return parse_version(&s);
        }
    }
    let utf16: Vec<u8> = ascii.iter().flat_map(|&b| [b, 0u8]).collect();
    if let Some(pos) = byte_find(&data, &utf16) {
        let mut s = String::new();
        let mut i = pos + utf16.len();
        while i + 1 < data.len() && data[i + 1] == 0 && is_ver_char(data[i]) && s.len() < 48 {
            s.push(data[i] as char);
            i += 2;
        }
        if !s.is_empty() {
            return parse_version(&s);
        }
    }
    (String::new(), String::new())
}

fn version_from_folder(path: &str) -> String {
    let name = Path::new(path).file_name().and_then(|s| s.to_str()).unwrap_or("");
    for tok in name.split(|c: char| !(c.is_ascii_digit() || c == '.')) {
        if tok.contains('.') && tok.chars().next().map(|c| c.is_ascii_digit()).unwrap_or(false) {
            return tok.to_string();
        }
    }
    String::new()
}

pub fn inspect_build(path: &str) -> BuildInspection {
    let root = Path::new(path);
    let fortnite_game = root.join("FortniteGame").is_dir();
    let engine = root.join("Engine").is_dir();
    let shipping_path = win64_dir(path).join("FortniteClient-Win64-Shipping.exe");
    let shipping = shipping_path.is_file();

    let anticheat = match detect_anticheat(path) {
        AntiCheat::Be => "Be",
        AntiCheat::Eac => "Eac",
        AntiCheat::None => "None",
    }
    .to_string();

    let (mut version, mut build) = if shipping {
        scan_version(&shipping_path)
    } else {
        (String::new(), String::new())
    };
    if version.is_empty() {
        let fv = version_from_folder(path);
        if !fv.is_empty() {
            version = fv.clone();
            if build.is_empty() {
                build = fv;
            }
        }
    }

    BuildInspection {
        fortnite_game,
        engine,
        shipping,
        anticheat,
        version,
        build,
        splash: read_splash_data_url(path),
    }
}

#[cfg(windows)]
mod platform {
    use super::*;
    use std::ffi::c_void;
    use std::os::raw::c_char;
    use std::path::Path;
    use std::thread;
    use std::time::Duration;

    #[allow(non_snake_case)]
    #[repr(C)]
    struct STARTUPINFOW {
        cb: u32,
        lpReserved: *mut u16,
        lpDesktop: *mut u16,
        lpTitle: *mut u16,
        dwX: u32,
        dwY: u32,
        dwXSize: u32,
        dwYSize: u32,
        dwXCountChars: u32,
        dwYCountChars: u32,
        dwFillAttribute: u32,
        dwFlags: u32,
        wShowWindow: u16,
        cbReserved2: u16,
        lpReserved2: *mut u8,
        hStdInput: *mut c_void,
        hStdOutput: *mut c_void,
        hStdError: *mut c_void,
    }

    #[allow(non_snake_case)]
    #[repr(C)]
    struct PROCESS_INFORMATION {
        hProcess: *mut c_void,
        hThread: *mut c_void,
        dwProcessId: u32,
        dwThreadId: u32,
    }

    #[link(name = "kernel32")]
    extern "system" {
        fn CreateProcessW(
            app: *const u16,
            cmd: *mut u16,
            proc_attrs: *mut c_void,
            thread_attrs: *mut c_void,
            inherit: i32,
            flags: u32,
            env: *mut c_void,
            cwd: *const u16,
            si: *mut STARTUPINFOW,
            pi: *mut PROCESS_INFORMATION,
        ) -> i32;
        fn VirtualAllocEx(h: *mut c_void, addr: *mut c_void, size: usize, typ: u32, prot: u32) -> *mut c_void;
        fn VirtualFreeEx(h: *mut c_void, addr: *mut c_void, size: usize, typ: u32) -> i32;
        fn WriteProcessMemory(h: *mut c_void, addr: *mut c_void, buf: *const c_void, size: usize, written: *mut usize) -> i32;
        fn GetProcAddress(module: *mut c_void, name: *const c_char) -> *mut c_void;
        fn GetModuleHandleW(name: *const u16) -> *mut c_void;
        fn CreateRemoteThread(h: *mut c_void, attrs: *mut c_void, stack: usize, start: *mut c_void, param: *mut c_void, flags: u32, tid: *mut u32) -> *mut c_void;
        fn WaitForSingleObject(h: *mut c_void, ms: u32) -> u32;
        fn CloseHandle(h: *mut c_void) -> i32;
        fn ResumeThread(h: *mut c_void) -> u32;
        fn TerminateProcess(h: *mut c_void, code: u32) -> i32;
    }

    const CREATE_SUSPENDED: u32 = 0x0000_0004;
    const CREATE_NO_WINDOW: u32 = 0x0800_0000;
    const MEM_COMMIT: u32 = 0x0000_1000;
    const MEM_RESERVE: u32 = 0x0000_2000;
    const MEM_RELEASE: u32 = 0x0000_8000;
    const PAGE_READWRITE: u32 = 0x04;
    const INFINITE: u32 = 0xFFFF_FFFF;
    const WAIT_TIMEOUT: u32 = 0x0000_0102;

    fn wide(s: &str) -> Vec<u16> {
        s.encode_utf16().chain(std::iter::once(0)).collect()
    }

    fn create_suspended(
        exe: &str,
        cmd: &str,
        cwd: Option<&str>,
        extra_flags: u32,
    ) -> Result<(*mut c_void, *mut c_void, u32), String> {
        let mut cmd_w = wide(&format!("\"{}\" {}", exe, cmd));
        let cwd_w = cwd.map(wide);
        let mut si: STARTUPINFOW = unsafe { std::mem::zeroed() };
        si.cb = std::mem::size_of::<STARTUPINFOW>() as u32;
        let mut pi: PROCESS_INFORMATION = unsafe { std::mem::zeroed() };

        let ok = unsafe {
            CreateProcessW(
                std::ptr::null(),
                cmd_w.as_mut_ptr(),
                std::ptr::null_mut(),
                std::ptr::null_mut(),
                0,
                CREATE_SUSPENDED | extra_flags,
                std::ptr::null_mut(),
                cwd_w.as_ref().map(|v| v.as_ptr()).unwrap_or(std::ptr::null()),
                &mut si,
                &mut pi,
            )
        };
        if ok == 0 {
            return Err(format!("CreateProcessW failed for {exe}"));
        }
        Ok((pi.hProcess, pi.hThread, pi.dwProcessId))
    }

    fn inject(h_process: *mut c_void, dll_path: &str) -> Result<(), String> {
        let path_bytes: Vec<u8> = {
            let mut v: Vec<u8> = Vec::new();
            for u in dll_path.encode_utf16().chain(std::iter::once(0)) {
                v.extend_from_slice(&u.to_le_bytes());
            }
            v
        };
        let size = path_bytes.len();

        let remote = unsafe {
            VirtualAllocEx(h_process, std::ptr::null_mut(), size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE)
        };
        if remote.is_null() {
            return Err("VirtualAllocEx failed".into());
        }

        let mut written: usize = 0;
        let wpm = unsafe {
            WriteProcessMemory(h_process, remote, path_bytes.as_ptr() as *const c_void, size, &mut written)
        };
        if wpm == 0 {
            unsafe { VirtualFreeEx(h_process, remote, 0, MEM_RELEASE) };
            return Err("WriteProcessMemory failed".into());
        }

        let k32 = unsafe { GetModuleHandleW(wide("kernel32.dll").as_ptr()) };
        let load_library_w = unsafe { GetProcAddress(k32, b"LoadLibraryW\0".as_ptr() as *const c_char) };
        if load_library_w.is_null() {
            unsafe { VirtualFreeEx(h_process, remote, 0, MEM_RELEASE) };
            return Err("GetProcAddress(LoadLibraryW) failed".into());
        }

        let mut tid: u32 = 0;
        let h_thread = unsafe {
            CreateRemoteThread(h_process, std::ptr::null_mut(), 0, load_library_w, remote, 0, &mut tid)
        };
        if h_thread.is_null() {
            unsafe { VirtualFreeEx(h_process, remote, 0, MEM_RELEASE) };
            return Err("CreateRemoteThread failed".into());
        }

        let wait = unsafe { WaitForSingleObject(h_thread, 30_000) };
        unsafe {
            CloseHandle(h_thread);
            VirtualFreeEx(h_process, remote, 0, MEM_RELEASE);
        }
        if wait == WAIT_TIMEOUT {
            return Err("Hook DLL DllMain didn't return within 30s (likely a hang).".into());
        }
        Ok(())
    }

    fn fake_ac(file_name: &str, args: &str) -> Option<*mut c_void> {
        let spoof_dir = std::env::temp_dir().join(format!("ARC-FakeAC-{}", std::process::id()));
        let _ = std::fs::create_dir_all(&spoof_dir);
        let spoof = spoof_dir.join(file_name);
        if std::fs::copy(stub_path(), &spoof).is_err() {
            return None;
        }
        match create_suspended(
            &spoof.to_string_lossy(),
            args,
            Some(&spoof_dir.to_string_lossy()),
            CREATE_NO_WINDOW,
        ) {
            Ok((hp, ht, _)) => {
                unsafe { CloseHandle(ht) };
                Some(hp)
            }
            Err(_) => None,
        }
    }

    pub fn launch(exe: String, args: String, hook_dll: String, ac: AntiCheat) -> Result<u32, String> {
        let ac_name = ac_exe_name(ac);
        let h_ac = if !ac_name.is_empty() { fake_ac(ac_name, &args) } else { None };
        let h_launcher = fake_ac("FortniteLauncher.exe", &args);

        let workdir = Path::new(&exe)
            .parent()
            .map(|p| p.to_string_lossy().to_string());
        let (h_proc, h_thread, pid) = match create_suspended(&exe, &args, workdir.as_deref(), 0) {
            Ok(v) => v,
            Err(e) => {
                terminate(h_ac);
                terminate(h_launcher);
                return Err(e);
            }
        };

        if let Err(e) = inject(h_proc, &hook_dll) {
            unsafe {
                TerminateProcess(h_proc, 1);
                CloseHandle(h_thread);
                CloseHandle(h_proc);
            }
            terminate(h_ac);
            terminate(h_launcher);
            return Err(e);
        }

        unsafe {
            ResumeThread(h_thread);
            CloseHandle(h_thread);
        }

        let h_ac_addr = h_ac.map(|p| p as usize);
        let h_launcher_addr = h_launcher.map(|p| p as usize);
        let proc_addr = h_proc as usize;
        thread::spawn(move || {
            unsafe {
                WaitForSingleObject(proc_addr as *mut c_void, INFINITE);
                CloseHandle(proc_addr as *mut c_void);
            }
            if let Some(a) = h_ac_addr {
                terminate(Some(a as *mut c_void));
            }
            if let Some(a) = h_launcher_addr {
                terminate(Some(a as *mut c_void));
            }
            let _ = std::fs::remove_dir_all(
                std::env::temp_dir().join(format!("ARC-FakeAC-{}", std::process::id())),
            );
        });

        thread::sleep(Duration::from_millis(120));

        Ok(pid)
    }

    fn terminate(h: Option<*mut c_void>) {
        if let Some(p) = h {
            if !p.is_null() {
                unsafe {
                    TerminateProcess(p, 0);
                    CloseHandle(p);
                }
            }
        }
    }
}

#[cfg(not(windows))]
mod platform {
    use super::*;
    pub fn launch(_exe: String, _args: String, _hook: String, _ac: AntiCheat) -> Result<u32, String> {
        Err("The ARC launcher can only start Fortnite on Windows.".into())
    }
}
