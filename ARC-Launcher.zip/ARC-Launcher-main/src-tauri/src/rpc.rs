use discord_rich_presence::{
    activity::{Activity, Assets, Button, Timestamps},
    DiscordIpc, DiscordIpcClient,
};
use std::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};

pub const CLIENT_ID: &str = "1560337700635156593";
pub const INVITE_URL: &str = "https://discord.gg/yhcWhVyDpC";

static CLIENT: Mutex<Option<DiscordIpcClient>> = Mutex::new(None);
static START: Mutex<Option<i64>> = Mutex::new(None);

fn now_secs() -> i64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs() as i64).unwrap_or(0)
}

pub fn update(skin_url: Option<String>, skin_name: Option<String>, player_name: Option<String>, in_game: bool) {
    let mut guard = match CLIENT.lock() { Ok(g) => g, Err(_) => return };

    if guard.is_none() {
        match DiscordIpcClient::new(CLIENT_ID) {
            Ok(mut c) => {
                if c.connect().is_ok() {
                    *guard = Some(c);
                    let mut s = START.lock().unwrap();
                    if s.is_none() { *s = Some(now_secs()); }
                } else {
                    return;
                }
            }
            Err(_) => return,
        }
    }

    let start = START.lock().ok().and_then(|s| *s).unwrap_or_else(now_secs);
    let large_image = skin_url.unwrap_or_default();
    let large_text = skin_name.filter(|s| !s.is_empty()).unwrap_or_else(|| "ARC".to_string());
    let name = player_name.filter(|s| !s.is_empty()).unwrap_or_else(|| "a player".to_string());

    let details = if in_game { "Playing 4.2 with ARC".to_string() } else { "In the ARC Launcher".to_string() };
    let state = format!("Logged in as {}", name);

    if let Some(client) = guard.as_mut() {
        let mut assets = Assets::new().small_image("arc").small_text("ARC");
        if !large_image.is_empty() {
            assets = assets.large_image(&large_image).large_text(&large_text);
        } else {
            assets = Assets::new().large_image("arc").large_text("ARC");
        }
        let activity = Activity::new()
            .details(&details)
            .state(&state)
            .assets(assets)
            .buttons(vec![Button::new("Join the ARC Discord", INVITE_URL)])
            .timestamps(Timestamps::new().start(start));

        if client.set_activity(activity).is_err() {
            *guard = None;
        }
    }
}

pub fn clear() {
    if let Ok(mut guard) = CLIENT.lock() {
        if let Some(client) = guard.as_mut() {
            let _ = client.clear_activity();
        }
        *guard = None;
    }
}
