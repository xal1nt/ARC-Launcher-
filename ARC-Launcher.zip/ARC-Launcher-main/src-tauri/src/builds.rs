use std::fs::{self, File, OpenOptions};
use std::io::{self, BufWriter, Read, Seek, SeekFrom, Write};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};

use futures_util::StreamExt;

pub static CANCEL: AtomicBool = AtomicBool::new(false);

#[derive(Clone, serde::Serialize)]
pub struct Progress {
    pub phase: String,
    pub done: u64,
    pub total: u64,
    pub speed: u64,
    pub file: String,
}

fn cancelled() -> bool {
    CANCEL.load(Ordering::Relaxed)
}

pub async fn download(url: &str, part: &Path, mut report: impl FnMut(Progress)) -> Result<(), String> {
    let client = reqwest::Client::builder()
        .connect_timeout(Duration::from_secs(20))
        .user_agent("ARC-Launcher")
        .build()
        .map_err(|e| e.to_string())?;

    let mut have = fs::metadata(part).map(|m| m.len()).unwrap_or(0);
    let mut req = client.get(url);
    if have > 0 {
        req = req.header(reqwest::header::RANGE, format!("bytes={}-", have));
    }
    let resp = req.send().await.map_err(|e| format!("couldn't reach the download server: {e}"))?;
    let status = resp.status();
    if status == reqwest::StatusCode::RANGE_NOT_SATISFIABLE && have > 0 {
        report(Progress { phase: "download".into(), done: have, total: have, speed: 0, file: String::new() });
        return Ok(());
    }
    if !status.is_success() {
        return Err(format!("download server said {status}"));
    }
    let resumed = status == reqwest::StatusCode::PARTIAL_CONTENT;
    if !resumed {
        have = 0;
    }
    let total = resp.content_length().map(|n| n + have).unwrap_or(0);

    let f = OpenOptions::new().create(true).write(true).open(part).map_err(|e| format!("can't write to the folder: {e}"))?;
    let mut f = BufWriter::with_capacity(4 << 20, f);
    if resumed {
        f.seek(SeekFrom::Start(have)).map_err(|e| e.to_string())?;
    } else {
        f.get_ref().set_len(0).map_err(|e| e.to_string())?;
    }

    let mut done = have;
    let mut stream = resp.bytes_stream();
    let started = Instant::now();
    let mut last = Instant::now();
    let mut window_bytes: u64 = 0;
    let mut window_at = Instant::now();
    let mut speed: u64 = 0;
    while let Some(chunk) = stream.next().await {
        if cancelled() {
            f.flush().ok();
            return Err("cancelled".into());
        }
        let chunk = chunk.map_err(|e| format!("download interrupted: {e} (start it again to resume)"))?;
        f.write_all(&chunk).map_err(|e| format!("couldn't write the file (disk full?): {e}"))?;
        done += chunk.len() as u64;
        window_bytes += chunk.len() as u64;
        if window_at.elapsed() >= Duration::from_secs(1) {
            speed = (window_bytes as f64 / window_at.elapsed().as_secs_f64()) as u64;
            window_bytes = 0;
            window_at = Instant::now();
        }
        if last.elapsed() >= Duration::from_millis(250) {
            last = Instant::now();
            report(Progress { phase: "download".into(), done, total, speed, file: String::new() });
        }
    }
    f.flush().map_err(|e| e.to_string())?;
    let _ = started;
    report(Progress { phase: "download".into(), done, total: total.max(done), speed, file: String::new() });
    Ok(())
}

pub enum Kind {
    Zip,
    SevenZ,
    Rar,
    Unknown,
}

pub fn kind_of(path: &Path) -> Kind {
    let mut head = [0u8; 8];
    let n = File::open(path).and_then(|mut f| f.read(&mut head)).unwrap_or(0);
    let h = &head[..n];
    if h.starts_with(b"PK\x03\x04") || h.starts_with(b"PK\x05\x06") {
        Kind::Zip
    } else if h.starts_with(&[0x37, 0x7A, 0xBC, 0xAF, 0x27, 0x1C]) {
        Kind::SevenZ
    } else if h.starts_with(b"Rar!") {
        Kind::Rar
    } else {
        Kind::Unknown
    }
}

pub fn extract_zip(archive: &Path, dest: &Path, mut report: impl FnMut(Progress)) -> Result<(), String> {
    let f = File::open(archive).map_err(|e| e.to_string())?;
    let mut zip = zip::ZipArchive::new(io::BufReader::with_capacity(1 << 20, f)).map_err(|e| format!("the download isn't a valid zip: {e}"))?;
    let mut total: u64 = 0;
    for i in 0..zip.len() {
        if let Ok(e) = zip.by_index_raw(i) {
            total += e.size();
        }
    }
    let mut done: u64 = 0;
    let mut last = Instant::now();
    let mut buf = vec![0u8; 1 << 20];
    for i in 0..zip.len() {
        if cancelled() {
            return Err("cancelled".into());
        }
        let mut entry = zip.by_index(i).map_err(|e| e.to_string())?;
        let Some(rel) = entry.enclosed_name() else { continue };
        let out = dest.join(rel);
        if entry.is_dir() {
            fs::create_dir_all(&out).map_err(|e| e.to_string())?;
            continue;
        }
        if let Some(p) = out.parent() {
            fs::create_dir_all(p).map_err(|e| e.to_string())?;
        }
        let name = out.file_name().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
        let mut w = BufWriter::with_capacity(1 << 20, File::create(&out).map_err(|e| format!("couldn't create {}: {e}", out.display()))?);
        loop {
            if cancelled() {
                return Err("cancelled".into());
            }
            let n = entry.read(&mut buf).map_err(|e| format!("broken file in the zip ({name}): {e}"))?;
            if n == 0 {
                break;
            }
            w.write_all(&buf[..n]).map_err(|e| format!("couldn't write (disk full?): {e}"))?;
            done += n as u64;
            if last.elapsed() >= Duration::from_millis(250) {
                last = Instant::now();
                report(Progress { phase: "extract".into(), done, total, speed: 0, file: name.clone() });
            }
        }
        w.flush().map_err(|e| e.to_string())?;
    }
    report(Progress { phase: "extract".into(), done: total, total, speed: 0, file: String::new() });
    Ok(())
}

pub fn extract_7z(archive: &Path, dest: &Path, mut report: impl FnMut(Progress)) -> Result<(), String> {
    let total: u64 = {
        let r = sevenz_rust2::SevenZReader::open(archive, sevenz_rust2::Password::empty()).map_err(|e| format!("the download isn't a valid 7z: {e}"))?;
        r.archive().files.iter().map(|f| f.size()).sum()
    };
    let mut done: u64 = 0;
    let mut last = Instant::now();
    sevenz_rust2::decompress_file_with_extract_fn(archive, dest, |entry, reader, path| {
        if cancelled() {
            return Err(sevenz_rust2::Error::other("cancelled"));
        }
        let ok = sevenz_rust2::default_entry_extract_fn(entry, reader, path)?;
        done += entry.size();
        if last.elapsed() >= Duration::from_millis(250) {
            last = Instant::now();
            report(Progress { phase: "extract".into(), done, total, speed: 0, file: entry.name().to_string() });
        }
        Ok(ok)
    })
    .map_err(|e| if cancelled() { "cancelled".to_string() } else { format!("couldn't unpack the 7z: {e}") })?;
    report(Progress { phase: "extract".into(), done: total, total, speed: 0, file: String::new() });
    Ok(())
}

pub fn find_build_root(dir: &Path, depth: u32) -> Option<PathBuf> {
    if dir.join("Engine").is_dir() && dir.join("FortniteGame").is_dir() {
        return Some(dir.to_path_buf());
    }
    if depth == 0 {
        return None;
    }
    let mut subs: Vec<PathBuf> = fs::read_dir(dir).ok()?.flatten().map(|e| e.path()).filter(|p| p.is_dir()).collect();
    subs.sort();
    subs.iter().find_map(|p| find_build_root(p, depth - 1))
}

pub fn extract_rar(archive: &Path, dest: &Path, mut report: impl FnMut(Progress)) -> Result<(), String> {
    let mut total: u64 = 0;
    if let Ok(list) = unrar::Archive::new(archive).open_for_listing() {
        for e in list.flatten() {
            total += e.unpacked_size;
        }
    }
    let mut done: u64 = 0;
    let mut last = Instant::now();
    let mut arc = unrar::Archive::new(archive).open_for_processing().map_err(|e| format!("the download isn't a valid rar: {e}"))?;
    loop {
        if cancelled() {
            return Err("cancelled".into());
        }
        let Some(header) = arc.read_header().map_err(|e| format!("broken rar: {e}"))? else { break };
        let size = header.entry().unpacked_size;
        let name = header.entry().filename.to_string_lossy().to_string();
        arc = if header.entry().is_file() {
            header.extract_with_base(dest).map_err(|e| format!("couldn't unpack {name} (disk full?): {e}"))?
        } else {
            header.skip().map_err(|e| e.to_string())?
        };
        done += size;
        if last.elapsed() >= Duration::from_millis(250) {
            last = Instant::now();
            report(Progress { phase: "extract".into(), done, total, speed: 0, file: name });
        }
    }
    report(Progress { phase: "extract".into(), done: total.max(done), total: total.max(done), speed: 0, file: String::new() });
    Ok(())
}

use tauri::{AppHandle, Emitter};

fn free_bytes(path: &Path) -> Option<u64> {
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::ffi::OsStrExt;
        let wide: Vec<u16> = path.as_os_str().encode_wide().chain(std::iter::once(0)).collect();
        let mut avail: u64 = 0;
        let ok = unsafe {
            windows_sys::Win32::Storage::FileSystem::GetDiskFreeSpaceExW(wide.as_ptr(), &mut avail, std::ptr::null_mut(), std::ptr::null_mut())
        };
        if ok != 0 { return Some(avail); }
    }
    let _ = path;
    None
}

#[tauri::command]
pub async fn download_build(app: AppHandle, url: String, dest: String) -> Result<String, String> {
    CANCEL.store(false, Ordering::Relaxed);
    let dest = PathBuf::from(dest);
    fs::create_dir_all(&dest).map_err(|e| format!("can't use that folder: {e}"))?;
    let part = dest.join(".arc-build.download");

    if let Ok(resp) = reqwest::Client::new().head(&url).send().await {
        if let Some(size) = resp.content_length() {
            let have = fs::metadata(&part).map(|m| m.len()).unwrap_or(0);
            let need = size.saturating_sub(have) + size + (1u64 << 30);
            if let Some(free) = free_bytes(&dest) {
                if free < need {
                    return Err(format!(
                        "Not enough space on that drive: need about {:.1} GB free, you have {:.1} GB.",
                        need as f64 / 1e9, free as f64 / 1e9
                    ));
                }
            }
        }
    }

    let a1 = app.clone();
    download(&url, &part, move |p| { let _ = a1.emit("build-progress", p); }).await?;

    let a2 = app.clone();
    let (d2, p2) = (dest.clone(), part.clone());
    tauri::async_runtime::spawn_blocking(move || {
        let emit = move |p: Progress| { let _ = a2.emit("build-progress", p); };
        match kind_of(&p2) {
            Kind::Zip => extract_zip(&p2, &d2, emit),
            Kind::SevenZ => extract_7z(&p2, &d2, emit),
            Kind::Rar => extract_rar(&p2, &d2, emit),
            Kind::Unknown => Err("The download isn't a zip, 7z or rar - check the build link.".into()),
        }
    })
    .await
    .map_err(|e| e.to_string())??;

    let _ = fs::remove_file(&part);
    let root = find_build_root(&dest, 5).ok_or("Unpacked, but no folder with Engine + FortniteGame was found in it.")?;
    let _ = app.emit("build-progress", Progress { phase: "done".into(), done: 1, total: 1, speed: 0, file: String::new() });
    Ok(root.to_string_lossy().to_string())
}

#[tauri::command]
pub fn cancel_build_download() {
    CANCEL.store(true, Ordering::Relaxed);
}
