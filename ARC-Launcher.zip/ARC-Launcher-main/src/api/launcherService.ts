import { useAuthStore } from "../stores/authStore";

export const BACKEND_URL = "http://15.204.255.118:3551";
const BASE_URL = `${BACKEND_URL}/api/launcher`;

export interface PatchNote {
  id: string;
  version: string;
  date: string;
  title: string;
  summary: string;
  whatsNew: { label: string; detail: string }[];
  fixes: string[];
}

export interface ServiceStatus {
  maintenance: boolean;
  message: string;
  eta: string | null;
}

export interface StreamData {
  status: ServiceStatus;
  patchNotes: PatchNote[];
}

export interface LaunchCreds {
  accountId: string;
  username: string;
  email: string;
  password: string;
  token: string;
}

export interface Me {
  accountId: string;
  username: string;
  discordId: string | null;
  discordName: string | null;
  discordAvatarUrl: string | null;
  discordRole: string | null;
  discordRoleColor: string | null;
}

export interface ActiveSkin {
  templateId: string | null;
  shortId: string | null;
  imageUrl: string | null;
}

export interface ShopItem {
  id: string;
  type: string;
  name: string;
  image: string;
  icon: string;
  featuredImage: string;
  banner: string;
  rarity: string;
  price: number;
  offerId: string;
  description: string;
  grant: string;
}

export interface Shop {
  featured: ShopItem[];
  daily: ShopItem[];
  updatedAt: string;
}

async function getJson<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, init);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as any)?.message || `HTTP ${res.status}`);
  return data as T;
}

function postJson<T>(path: string, body: unknown): Promise<T> {
  return getJson<T>(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

export function discordStart() {
  return getJson<{ ok: boolean; state: string; url: string; message?: string }>("/discord/start");
}

export type DiscordPoll =
  | { status: "pending" }
  | { status: "new"; discordId: string; discordUsername: string; avatar: string | null }
  | ({ status: "ok" } & LaunchCreds)
  | { status: "error"; message: string }
  | { status: "expired" };

export function discordPoll(state: string) {
  return getJson<DiscordPoll>(`/discord/poll?state=${encodeURIComponent(state)}`);
}

export function discordRegister(state: string, username: string) {
  return postJson<{ success: boolean; message?: string } & Partial<LaunchCreds>>("/discord/register", { state, username });
}

export function usernameCheck(u: string) {
  return getJson<{ available: boolean; reason?: string }>(`/username-check?u=${encodeURIComponent(u)}`);
}

export function usernameSuggest() {
  return getJson<{ username: string }>("/username-suggest");
}

export function validateSession(accountId: string, token: string) {
  return postJson<{ success: boolean; username?: string }>("/session", { accountId, token });
}

export function getMe(accountId: string) {
  return getJson<Me>(`/me?accountId=${encodeURIComponent(accountId)}`);
}

export function getActiveSkin(accountId: string) {
  return getJson<ActiveSkin>(`/active-skin?accountId=${encodeURIComponent(accountId)}`);
}

export function getVbucks(accountId: string) {
  return getJson<{ vbucks: number }>(`/vbucks?accountId=${encodeURIComponent(accountId)}`);
}

export function getOwned(accountId: string) {
  return getJson<{ owned: string[] }>(`/owned?accountId=${encodeURIComponent(accountId)}`);
}

export function getShop() {
  return getJson<Shop>("/itemshop");
}

export function buyItem(accountId: string, offerId: string) {
  return postJson<{ ok: boolean; message?: string; vbucks?: number }>("/buy", { accountId, offerId });
}

export interface BpReward {
  tier: number;
  templateId: string;
  name: string;
  image: string;
  rarity: string;
  type: string;
  paid: boolean;
  locked: boolean;
  xpNeeded: number;
}
export interface BattlePass {
  season: number;
  owned: boolean;
  tier: number;
  maxed: boolean;
  level: number;
  levelXp: number;
  levelXpNeeded: number;
  tierXp: number;
  tierXpNeeded: number;
  xpToNextTier: number;
  lifetimeXp: number;
  next: BpReward | null;
  nextPaid: BpReward | null;
  upcoming: (BpReward | null)[];
}

export function getBattlePass(accountId: string) {
  return getJson<BattlePass>(`/battlepass?accountId=${encodeURIComponent(accountId)}`);
}

function authHeaders(): Record<string, string> {
  const c = useAuthStore.getState().creds;
  return c ? { "x-accountid": c.accountId, "x-arc-token": c.token } : {};
}
function authGet<T>(path: string) {
  return getJson<T>(path, { headers: authHeaders() });
}
function authPost<T>(path: string, body: unknown) {
  return getJson<T>(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...authHeaders() },
    body: JSON.stringify(body),
  });
}

export interface Cosmetic {
  templateId: string;
  name: string;
  image: string;
  rarity: string;
  type: string;
  season: string;
}
export interface ReelItem { name: string; image: string; rarity: string; templateId?: string; season?: string }
export interface CrateInfo {
  id: string;
  name: string;
  price: number;
  color: string;
  odds: Record<string, number>;
  preview: ReelItem[];
  count: number;
  seasonCap?: number;
}
export interface CasinoConfig {
  enabled: boolean;
  coinflip: { min: number; max: number };
  crates: CrateInfo[];
}
export interface CratePrize extends ReelItem {
  kind: "cosmetic" | "vbucks" | "duplicate";
  amount?: number;
  type?: string;
}
export interface CasinoWin {
  username: string;
  templateId?: string;
  game: string;
  label: string;
  image: string;
  rarity: string;
  bet: number;
  payout: number;
  createdAt: string;
}

export function getCasinoConfig() {
  return getJson<CasinoConfig>("/casino/config");
}
export function getCasinoRecent() {
  return getJson<{ wins: CasinoWin[] }>("/casino/recent");
}
export function openCrate(crateId: string) {
  return authPost<{ ok: boolean; prize: CratePrize; reel: ReelItem[]; winIndex: number; vbucks: number; message?: string }>(
    "/casino/crate", { crateId });
}
export function coinflip(bet: number, side: "heads" | "tails") {
  return authPost<{ ok: boolean; result: "heads" | "tails"; won: boolean; payout: number; vbucks: number; message?: string }>(
    "/casino/coinflip", { bet, side });
}

export interface Trade {
  tradeId: string;
  fromId: string;
  fromName: string;
  toId: string;
  toName: string;
  give: Cosmetic[];
  giveVbucks: number;
  want: Cosmetic[];
  wantVbucks: number;
  message: string;
  status: "pending" | "accepted" | "declined" | "cancelled" | "failed" | "expired";
  reason: string;
  createdAt: string;
  updatedAt: string;
  expiresAt: string;
}
export interface TradePlayer { accountId: string; username: string; avatar: string | null }

export function getTradeLocker(username?: string) {
  const q = username ? `?username=${encodeURIComponent(username)}` : "";
  return authGet<{ ok: boolean; accountId: string; username: string; items: Cosmetic[]; vbucks?: number }>(`/trade/locker${q}`);
}
export function searchPlayers(q: string) {
  return authGet<{ players: TradePlayer[] }>(`/trade/search?q=${encodeURIComponent(q)}`);
}
export function getTrades() {
  return authGet<{ ok: boolean; incoming: Trade[]; outgoing: Trade[]; history: Trade[] }>("/trade/list");
}
export function getTradeCount() {
  return authGet<{ incoming: number }>("/trade/count");
}
export function createTrade(body: { to: string; give: string[]; giveVbucks: number; want: string[]; wantVbucks: number; message: string }) {
  return authPost<{ ok: boolean; message?: string; trade?: Trade }>("/trade/create", body);
}
export function tradeAction(action: "accept" | "decline" | "cancel", tradeId: string) {
  return authPost<{ ok: boolean; message?: string; vbucks?: number }>(`/trade/${action}`, { tradeId });
}

type StreamListener = (data: StreamData) => void;

let currentData: StreamData = {
  status: { maintenance: false, message: "", eta: null },
  patchNotes: [],
};
const listeners = new Set<StreamListener>();
let pollTimer: number | null = null;

function notify(): void {
  for (const listener of listeners) listener(currentData);
}

function mapPatchNotes(raw: any): PatchNote[] {
  const notes: any[] = Array.isArray(raw?.notes) ? raw.notes : [];
  return notes.map((n, i) => {
    const body = String(n.body || "");
    const lines = body.split("\n").map((l: string) => l.trim()).filter(Boolean);
    const bullets = lines.filter((l: string) => /^[•\-*]/.test(l)).map((l: string) => l.replace(/^[•\-*]\s*/, ""));
    const summary = lines.find((l: string) => !/^[•\-*]/.test(l)) || bullets[0] || "";
    return {
      id: String(n.id ?? i),
      version: String(n.tag || "UPDATE"),
      date: String(n.date || ""),
      title: String(n.title || "Update"),
      summary,
      whatsNew: bullets.map((b: string) => ({ label: "", detail: b })),
      fixes: [],
    };
  });
}

let failures = 0;
const DOWN_MSG = "ARC is currently unreachable. We'll be back shortly.";

async function pollOnce() {
  let ok = false;
  try {
    const r = await fetch(`${BASE_URL}/ping`, { cache: "no-store" });
    ok = r.ok;
  } catch (e) {
    console.warn("[ARC] ping failed:", e);
  }
  failures = ok ? 0 : failures + 1;

  const maintenance = failures >= 3;
  let notes: any = null;
  if (ok) notes = await getJson<any>("/patchnotes").catch(() => null);
  currentData = {
    status: maintenance ? { maintenance: true, message: DOWN_MSG, eta: null } : { maintenance: false, message: "", eta: null },
    patchNotes: notes ? mapPatchNotes(notes) : currentData.patchNotes,
  };
  notify();
}

export function connectStream(): void {
  if (pollTimer !== null) return;
  pollOnce();
  pollTimer = window.setInterval(pollOnce, 5000);
}

export function disconnectStream(): void {
  if (pollTimer !== null) window.clearInterval(pollTimer);
  pollTimer = null;
}

export function subscribe(listener: StreamListener): () => void {
  listeners.add(listener);
  listener(currentData);
  return () => listeners.delete(listener);
}

export function getStreamData(): StreamData {
  return currentData;
}

export interface LiveServer {
  id: string;
  region: string;
  playlist: string;
  name: string;
  image: string | null;
  players: number;
  alive: number;
  bots: number;
  maxplayers: number;
  status: "online" | "gamestarted" | "gameended" | string;
  startedAt: string | null;
  upSeconds: number;
}
export function getServers() {
  return getJson<{ count: number; servers: LiveServer[] }>("/servers");
}

export function getTesterStatus() {
  return authGet<{ ok: boolean; tester: boolean; claimed: boolean; dismissed: boolean }>("/tester");
}
export function claimFullLocker() {
  return authPost<{ ok: boolean; granted: number; skipped: number; sample: string[] }>("/tester/claim", {});
}
export function dismissFullLocker() {
  return authPost<{ ok: boolean }>("/tester/dismiss", {});
}
