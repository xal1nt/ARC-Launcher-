export const RARITY_COLORS: Record<string, string> = {
  legendary: "#e9a133",
  epic: "#b347e8",
  rare: "#2f8cf0",
  uncommon: "#5ec34a",
  common: "#8a8a8a",
  vbucks: "#36c2ff",
};

export function cosmeticId(templateId?: string): string {
  if (!templateId) return "";
  const i = templateId.indexOf(":");
  return i >= 0 ? templateId.slice(i + 1) : templateId;
}

export function rarityColor(r: string | undefined): string {
  return RARITY_COLORS[(r || "").toLowerCase()] || "#8a8a8a";
}
