import { useEffect, useRef, useState } from "react";
import { FaDiscord } from "react-icons/fa";
import { openUrl } from "@tauri-apps/plugin-opener";
import { useSettingsStore } from "../stores/settingsStore";
import { t } from "../i18n";
import { discordStart, discordPoll, type LaunchCreds } from "../api/launcherService";
import arcLogo from "../assets/arc-logo.png";
import "./Login.css";

interface LoginProps {
  onLogin: (creds: LaunchCreds, remember: boolean, profile: { discordName: string | null; avatarUrl: string | null }) => void;

  onNewPlayer: (p: { state: string; discordName: string; avatar: string | null }) => void;
}

type Stage = "idle" | "waiting";

function Login({ onLogin, onNewPlayer }: LoginProps) {
  const locale = useSettingsStore((s) => s.locale);
  const [stage, setStage] = useState<Stage>("idle");
  const [error, setError] = useState<string | null>(null);
  const pollRef = useRef<number | null>(null);

  function stopPolling() {
    if (pollRef.current !== null) window.clearInterval(pollRef.current);
    pollRef.current = null;
  }

  useEffect(() => () => stopPolling(), []);

  async function startDiscord() {
    setError(null);
    try {
      const res = await discordStart();
      if (!res.ok || !res.url) throw new Error(res.message || "Discord sign-in is unavailable.");
      setStage("waiting");
      await openUrl(res.url);
      stopPolling();
      pollRef.current = window.setInterval(async () => {
        try {
          const p = await discordPoll(res.state);
          if (p.status === "pending") return;
          stopPolling();
          if (p.status === "ok") {
            const { status: _s, ...creds } = p as any;
            onLogin(creds as LaunchCreds, true, { discordName: null, avatarUrl: null });
          } else if (p.status === "new") {
            onNewPlayer({ state: res.state, discordName: p.discordUsername, avatar: p.avatar });
            setStage("idle");
          } else if (p.status === "error") {
            setError(p.message);
            setStage("idle");
          } else {
            setError("Sign-in link expired. Try again.");
            setStage("idle");
          }
        } catch {
        }
      }, 2000);
    } catch (e: any) {
      setError(e?.message || "Could not start Discord sign-in.");
      setStage("idle");
    }
  }

  function cancel() {
    stopPolling();
    setStage("idle");
  }

  if (stage === "waiting") {
    return (
      <div className="signing-in">
        <div className="signing-in-spinner" />
        <span className="signing-in-text">Finish signing in with Discord in your browser…</span>
        <span className="login-note">Click "Login to ARC Launcher" in your browser - we'll pick up here automatically.</span>
        <button className="login-link" onClick={cancel}>Cancel</button>
      </div>
    );
  }

  return (
    <div className="login page">
      <div className="login-branding">
        <img className="login-logo" src={arcLogo} alt="ARC" />
      </div>
      <div className="login-panel">
        <h2 className="login-title">{t("login.title", locale)}</h2>
        <div className="login-form">
          <button className="login-button login-discord" type="button" onClick={startDiscord}>
            <FaDiscord /> Continue with Discord
          </button>
          {error && <span className="login-hint bad">{error}</span>}
          <span className="login-note">New here? Sign in with Discord and pick a username, or use /register in the ARC Discord.</span>
        </div>
      </div>
    </div>
  );
}

export default Login;
