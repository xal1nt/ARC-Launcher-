import { useEffect } from "react";
import { FaPlay, FaStop } from "react-icons/fa";
import { useLaunch } from "../hooks/useLaunch";
import { invoke } from "@tauri-apps/api/core";
import { useLibraryStore } from "../stores/libraryStore";
import "./QuickLaunch.css";

function QuickLaunch() {
  const { installed, installPath, icon, setInstalled } = useLibraryStore();
  const { launch, close, running, launching, error } = useLaunch();

  useEffect(() => {
    if (installed && installPath && !icon) {
      invoke<{ icon: string | null }>("detect_build_version", { path: installPath }).then((info) => {
        if (info.icon) {
          setInstalled(installPath, info.icon);
        }
      });
    }
  }, [installed, installPath, icon]);

  return (
    <div className={`quick-launch ${installed ? "visible" : "hidden"}`}>
      {icon ? (
        <img className="quick-launch-icon-img" src={icon} alt="icon" />
      ) : (
        <div className="quick-launch-icon" />
      )}
      <div className="quick-launch-info">
        <span className="quick-launch-name">Fortnite</span>
        <span className="quick-launch-version">4.2-CL-4072250</span>
      </div>
      <button
        className={`quick-launch-play ${running ? "running" : ""}`}
        title={error || (running ? "Close Fortnite" : "Play")}
        disabled={launching}
        onClick={running ? close : launch}
      >
        {launching ? <span className="quick-launch-spinner" /> : running ? <FaStop /> : <FaPlay />}
      </button>
      {error && <span className="quick-launch-error">{error}</span>}
    </div>
  );
}

export default QuickLaunch;
