import { getCurrentWindow } from "@tauri-apps/api/window";
import { VscChromeMinimize, VscChromeClose } from "react-icons/vsc";
import "./Titlebar.css";

declare const __APP_VERSION__: string;

const version = __APP_VERSION__;
const env = import.meta.env.MODE === "production" ? "prod" : "dev";

interface TitlebarProps {
  page?: string;
}

function Titlebar(_props: TitlebarProps) {
  const appWindow = getCurrentWindow();

  return (
    <div data-tauri-drag-region className="titlebar">
      <div data-tauri-drag-region className="titlebar-info">
        <span data-tauri-drag-region className="titlebar-title">ARC</span>
        <span data-tauri-drag-region className="titlebar-meta">
          {version} • {env}
        </span>
      </div>
      <div className="titlebar-buttons">
        <button className="titlebar-button" onClick={() => appWindow.minimize()}>
          <VscChromeMinimize />
        </button>
        <button className="titlebar-button titlebar-button-close" onClick={() => appWindow.close()}>
          <VscChromeClose />
        </button>
      </div>
    </div>
  );
}

export default Titlebar;
