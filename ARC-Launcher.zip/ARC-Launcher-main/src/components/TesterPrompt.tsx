import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { IoClose } from "react-icons/io5";
import { getTesterStatus, claimFullLocker, dismissFullLocker } from "../api/launcherService";
import { refreshProfile } from "../App";
import "./TesterPrompt.css";

type Step = "ask" | "working" | "done" | "error";

const icon = (tid: string) =>
  `https://fortnite-api.com/images/cosmetics/br/${(tid.split(":")[1] || tid).toLowerCase()}/icon.png`;

function TesterPrompt() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<Step>("ask");
  const [result, setResult] = useState<{ granted: number; sample: string[] } | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    getTesterStatus()
      .then((r) => { if (r.tester && !r.claimed && !r.dismissed) setOpen(true); })
      .catch(() => {});
  }, []);

  async function yes() {
    setStep("working");
    try {
      const r = await claimFullLocker();
      setResult({ granted: r.granted, sample: r.sample || [] });
      setStep("done");
      refreshProfile().catch(() => {});
    } catch (e: any) {
      setError(e?.message || "Something went wrong.");
      setStep("error");
    }
  }
  function no() {
    dismissFullLocker().catch(() => {});
    setOpen(false);
  }

  if (!open) return null;
  return createPortal(
    <div className="modal-overlay">
      <div className="modal tst-modal">
        {step !== "working" && (
          <button className="modal-close" onClick={step === "ask" ? no : () => setOpen(false)}><IoClose /></button>
        )}

        {(step === "ask" || step === "working") && (
          <>
            <span className="tst-big">Seems like you're a tester</span>
            <span className="modal-desc">Do you want the full locker? Every skin, pickaxe, glider, emote and back bling gets added to your account. Nothing you already own changes.</span>
            <div className="modal-actions modal-actions-right">
              <button className="modal-btn-text" onClick={no} disabled={step === "working"}>No</button>
              <button className="modal-btn modal-btn-sm tst-yes" onClick={yes} disabled={step === "working"}>
                {step === "working" ? "Adding…" : "Yes"}
              </button>
            </div>
          </>
        )}

        {step === "done" && result && (
          <>
            <span className="tst-big">Full locker unlocked</span>
            <span className="modal-desc">
              {result.granted > 0 ? <><b>{result.granted.toLocaleString()}</b> cosmetics added.</> : "You already had everything."}
              {" "}Restart Fortnite if it's open.
            </span>
            {result.sample.length > 0 && (
              <div className="tst-grid">
                {result.sample.map((t) => (
                  <img key={t} src={icon(t)} alt="" onError={(e) => ((e.target as HTMLImageElement).style.visibility = "hidden")} />
                ))}
              </div>
            )}
            <div className="modal-actions modal-actions-right">
              <button className="modal-btn modal-btn-sm tst-yes" onClick={() => setOpen(false)}>Nice</button>
            </div>
          </>
        )}

        {step === "error" && (
          <>
            <span className="tst-big">Couldn't add it</span>
            <span className="modal-desc">{error} You can also use /claimfulllocker in Discord.</span>
            <div className="modal-actions modal-actions-right">
              <button className="modal-btn-text" onClick={() => setOpen(false)}>Close</button>
              <button className="modal-btn modal-btn-sm tst-yes" onClick={yes}>Try again</button>
            </div>
          </>
        )}
      </div>
    </div>,
    document.body,
  );
}

export default TesterPrompt;
