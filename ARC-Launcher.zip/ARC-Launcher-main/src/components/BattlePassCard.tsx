import { useEffect, useState } from "react";
import { IoLockClosed } from "react-icons/io5";
import bpBadge from "../assets/battlepass.png";
import { getBattlePass, type BattlePass, type BpReward } from "../api/launcherService";
import { useAuthStore } from "../stores/authStore";
import "./BattlePassCard.css";

const fmt = (n: number) => Math.max(0, Math.round(n)).toLocaleString();

const TILE: Record<string, [string, string]> = {
  common: ["#bebebe", "#646464"],
  uncommon: ["#69bb1e", "#175117"],
  rare: ["#49b0ff", "#143977"],
  epic: ["#c359ff", "#4b2483"],
  legendary: ["#ea8d23", "#78371d"],
};
function tileBg(rarity?: string) {
  const [a, b] = TILE[(rarity || "").toLowerCase()] || TILE.common;
  return `radial-gradient(circle at 50% 40%, ${a} 0%, ${b} 100%)`;
}

function Tile({ r, size }: { r: BpReward; size: "lg" | "sm" }) {
  return (
    <div className={`bp-tile bp-tile-${size}`} style={{ background: tileBg(r.rarity) }} title={`${r.name} · Tier ${r.tier}`}>
      <img src={r.image} alt="" />
      {size === "sm" && <span>{r.tier}</span>}
    </div>
  );
}

function BattlePassCard() {
  const accountId = useAuthStore((s) => s.creds?.accountId);
  const [bp, setBp] = useState<BattlePass | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!accountId) return;
    let alive = true;
    const load = () =>
      getBattlePass(accountId)
        .then((r) => { if (alive) { setBp(r); setFailed(false); } })
        .catch(() => alive && setFailed(true));
    load();
    const h = window.setInterval(load, 60000);
    return () => { alive = false; window.clearInterval(h); };
  }, [accountId]);

  if (!bp) {
    return (
      <div className="bp-card bp-card-empty">
        {failed ? "Couldn't load your Battle Pass" : <div className="article-spinner" />}
      </div>
    );
  }

  const pct = bp.maxed ? 100 : Math.min(100, (bp.tierXp / Math.max(1, bp.tierXpNeeded)) * 100);
  const n = bp.next;
  const upcoming = bp.upcoming.filter(Boolean) as BpReward[];

  return (
    <div className="bp-card">
      <div className="bp-head">
        <img className="bp-badge" src={bpBadge} alt="" />
        <div>
          <div className="bp-tier">Tier {bp.tier}</div>
          <div className="bp-sub">Season {bp.season} · Level {bp.level}{!bp.owned && " · Free pass"}</div>
        </div>
      </div>

      <div className="bp-bar"><div style={{ width: `${pct}%` }} /></div>
      <div className="bp-bar-text">
        {bp.maxed ? "Max tier" : <>{fmt(bp.tierXp)} / {fmt(bp.tierXpNeeded)} XP</>}
      </div>

      {n ? (
        <div className="bp-next">
          <Tile r={n} size="lg" />
          <div className="bp-next-info">
            <div className="bp-next-name">{n.name}</div>
            <div className="bp-next-meta">{n.type} · Tier {n.tier}</div>
            <div className="bp-next-xp">{n.xpNeeded > 0 ? `${fmt(n.xpNeeded)} XP to go` : "Next match"}</div>
          </div>
        </div>
      ) : (
        <div className="bp-done">Everything on your pass is unlocked.</div>
      )}

      {bp.nextPaid ? (
        <div className="bp-locked"><IoLockClosed /> {bp.nextPaid.name} (Tier {bp.nextPaid.tier}) is on the paid pass</div>
      ) : upcoming.length > 0 && (
        <div className="bp-row">
          {upcoming.map((u) => <Tile key={u.templateId} r={u} size="sm" />)}
        </div>
      )}
    </div>
  );
}

export default BattlePassCard;
