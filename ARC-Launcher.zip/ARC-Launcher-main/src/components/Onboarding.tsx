import { useEffect, useRef, useState } from "react";
import { IoMusicalNotes, IoVolumeMute, IoCheckmark, IoShuffle } from "react-icons/io5";
import {
  discordPoll,
  discordRegister,
  usernameCheck,
  usernameSuggest,
  type LaunchCreds,
} from "../api/launcherService";
import { SOUNDTRACKS, type Soundtrack } from "../soundtracks";
import { useSettingsStore } from "../stores/settingsStore";
import arcWelcome from "../assets/arc-welcome.png";
import "./Onboarding.css";

export type OnboardingInfo =
  | { mode: "new"; state: string; discordName: string; avatar: string | null }
  | { mode: "existing"; discordName: string | null; avatar: string | null };

interface Props {
  info: OnboardingInfo;
  onAccount: (creds: LaunchCreds) => void;
  onDone: () => void;
  onCancel: () => void;
}

type Step = "welcome" | "username" | "creating" | "fade" | "soundtrack" | "confirm";
type NameState = { kind: "idle" | "checking" | "ok" | "bad"; text?: string };

function Onboarding({ info, onAccount, onDone, onCancel }: Props) {
  const [step, setStep] = useState<Step>("welcome");
  const [name, setName] = useState("");
  const [nameState, setNameState] = useState<NameState>({ kind: "idle" });
  const [error, setError] = useState<string | null>(null);
  const [picked, setPicked] = useState<Soundtrack | null>(null);
  const preview = useRef<HTMLAudioElement | null>(null);
  const checkSeq = useRef(0);
  const setSoundtrack = useSettingsStore((s) => s.setSoundtrack);
  const setSoundtrackChosen = useSettingsStore((s) => s.setSoundtrackChosen);
  const volume = useSettingsStore((s) => s.musicVolume);

  useEffect(() => {
    if (step !== "welcome") return;
    const h = window.setTimeout(nextFromWelcome, 4200);
    return () => window.clearTimeout(h);
  }, [step]);

  useEffect(() => {
    if (step !== "fade") return;
    const h = window.setTimeout(() => setStep("soundtrack"), 1100);
    return () => window.clearTimeout(h);
  }, [step]);

  useEffect(() => () => stopPreview(), []);

  function nextFromWelcome() {
    setStep(info.mode === "new" ? "username" : "fade");
  }

  useEffect(() => {
    if (step !== "username") return;
    const u = name.trim();
    if (!u) { setNameState({ kind: "idle" }); return; }
    const seq = ++checkSeq.current;
    setNameState({ kind: "checking" });
    const h = window.setTimeout(async () => {
      try {
        const r = await usernameCheck(u);
        if (seq !== checkSeq.current) return;
        setNameState(r.available ? { kind: "ok", text: "Nice - that one's yours if you want it." } : { kind: "bad", text: r.reason || "That username isn't available." });
      } catch {
        if (seq === checkSeq.current) setNameState({ kind: "idle" });
      }
    }, 400);
    return () => window.clearTimeout(h);
  }, [name, step]);

  async function suggest() {
    try {
      const r = await usernameSuggest();
      if (r.username) setName(r.username);
    } catch {  }
  }

  async function createAccount() {
    if (info.mode !== "new" || nameState.kind !== "ok") return;
    setError(null);
    setStep("creating");
    try {
      const r = await discordRegister(info.state, name.trim());
      if (!r.success) throw new Error(r.message || "Couldn't create your account.");

      for (let i = 0; i < 20; i++) {
        const p = await discordPoll(info.state);
        if (p.status === "ok") {
          const { status: _s, ...creds } = p as any;
          onAccount(creds as LaunchCreds);
          setStep("fade");
          return;
        }
        if (p.status === "error" || p.status === "expired") throw new Error("Your sign-in expired. Please sign in with Discord again.");
        await new Promise((res) => setTimeout(res, 1000));
      }
      throw new Error("The server took too long. Please try again.");
    } catch (e: any) {
      const msg = e?.message || "Something went wrong.";
      setError(msg);
      setStep("username");
      if (/expired/i.test(msg)) setTimeout(onCancel, 2500);
    }
  }

  function stopPreview() {
    if (preview.current) { preview.current.pause(); preview.current = null; }
  }

  function pick(t: Soundtrack) {
    setPicked(t);
    stopPreview();
    if (t.src) {
      const a = new Audio(t.src);
      a.loop = true;
      a.volume = volume;
      a.play().catch(() => {});
      preview.current = a;
    }
  }

  function confirm() {
    if (!picked) return;
    stopPreview();
    setSoundtrack(picked.id === "none" ? null : picked.id);
    setSoundtrackChosen(true);
    onDone();
  }

  const shownName = info.discordName || "player";

  if (step === "welcome") {
    return (
      <div className="onb onb-welcome" onClick={nextFromWelcome}>
        <div className="onb-welcome-inner">
          <span className="onb-kicker">Welcome to</span>
          <img className="onb-logo" src={arcWelcome} alt="ARC" draggable={false} />
          <div className="onb-who">
            {info.avatar ? <img className="onb-avatar" src={info.avatar} alt="" /> : <span className="onb-avatar blank">{shownName.slice(0, 1).toUpperCase()}</span>}
            <span className="onb-discord">{shownName}</span>
          </div>
          <span className="onb-tagline">Where Chapter 1 lives on.</span>
        </div>
      </div>
    );
  }

  if (step === "username" || step === "creating") {
    const busy = step === "creating";
    return (
      <div className="onb onb-panel-wrap">
        <div className="onb-panel">
          <h2 className="onb-title">Choose a username you want!</h2>
          <p className="onb-sub">Go ahead, pick something unique! This is the name everyone sees in game.</p>
          <div className="onb-name-row">
            <input
              className={`onb-input ${nameState.kind}`}
              value={name}
              maxLength={16}
              autoFocus
              disabled={busy}
              placeholder="Your username"
              onChange={(e) => setName(e.target.value.replace(/\s/g, ""))}
              onKeyDown={(e) => { if (e.key === "Enter") createAccount(); }}
            />
            <button className="onb-icon-btn" title="Suggest one" onClick={suggest} disabled={busy}>
              <IoShuffle />
            </button>
          </div>
          <span className={`onb-hint ${nameState.kind}`}>
            {nameState.kind === "checking" ? "Checking..." : nameState.text || "3-16 characters, letters, numbers and _"}
          </span>
          {error && <span className="onb-hint bad">{error}</span>}
          <button className="onb-btn" disabled={busy || nameState.kind !== "ok"} onClick={createAccount}>
            {busy ? "Creating your account..." : "That's the one"}
          </button>
        </div>
      </div>
    );
  }

  if (step === "fade") {
    return <div className="onb onb-black onb-fadein" />;
  }

  return (
    <div className="onb onb-black">
      <div className={`onb-music ${step === "confirm" ? "dim" : ""}`}>
        <h2 className="onb-title big onb-rise">Time for personalisation!</h2>
        <p className="onb-sub onb-rise delay">Pick a launcher soundtrack</p>
        <div className="onb-tracks onb-rise delay2">
          {SOUNDTRACKS.map((t) => (
            <button key={t.id} className={`onb-track ${picked?.id === t.id ? "picked" : ""}`} onClick={() => pick(t)}>
              <div className="onb-cover">
                {t.cover ? <img src={t.cover} alt="" /> : <IoVolumeMute className="onb-cover-icon" />}
                {picked?.id === t.id && <span className="onb-check"><IoCheckmark /></span>}
              </div>
              <span className="onb-track-name">{t.name}</span>
              <span className="onb-track-sub">{t.src ? <><IoMusicalNotes /> {t.subtitle}</> : t.subtitle}</span>
            </button>
          ))}
        </div>
        <button className="onb-btn wide onb-rise delay2" disabled={!picked} onClick={() => setStep("confirm")}>
          Continue
        </button>
      </div>

      {step === "confirm" && picked && (
        <div className="onb-confirm">
          <div className="onb-confirm-card">
            <h3 className="onb-title">Are you sure?</h3>
            <p className="onb-sub">
              <b>{picked.name}</b> will play in the launcher. You can change it any time in Settings.
            </p>
            <div className="onb-confirm-row">
              <button className="onb-btn ghost" onClick={() => setStep("soundtrack")}>Go back</button>
              <button className="onb-btn" onClick={confirm}>Yes, I'm sure</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Onboarding;
