import { useSettingsStore } from "../stores/settingsStore";
import { t } from "../i18n";
import arcLogo from "../assets/arc-logo.png";
import "./Splash.css";

function Splash() {
  const locale = useSettingsStore((s) => s.locale);

  return (
    <div className="splash">
      <img className="splash-logo" src={arcLogo} alt="ARC" />
      <div className="splash-spinner" />
      <span className="splash-text">{t("splash.checking", locale)}</span>
    </div>
  );
}

export default Splash;
