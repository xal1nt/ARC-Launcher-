import { useEffect, useState } from "react";
import slide1 from "../assets/slides/slide1.png";
import slide2 from "../assets/slides/slide2.png";
import slide3 from "../assets/slides/slide3.png";
import "./NewsSlider.css";

const SLIDES = [
  { image: slide1, title: "ARC is back", caption: "ARC is back with the original founders — thank you for trying us again!" },
  { image: slide2, title: "ARC V2", caption: "Expect much better gameplay!" },
  { image: slide3, title: "Support ARC", caption: "Consider contributing to ARC and receive exclusive perks." },
];

const DURATION_MS = 6000;

function NewsSlider() {
  const [index, setIndex] = useState(0);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const h = window.setTimeout(() => {
      setIndex((i) => (i + 1) % SLIDES.length);
      setTick((t) => t + 1);
    }, DURATION_MS);
    return () => window.clearTimeout(h);
  }, [index, tick]);

  function go(i: number) {
    setIndex(i);
    setTick((t) => t + 1);
  }

  return (
    <div className="news-slider">
      {SLIDES.map((s, i) => (
        <div key={i} className={`news-slide ${i === index ? "active" : ""}`} style={{ backgroundImage: `url(${s.image})` }}>
          <div className="news-slide-shade" />
          <div className="news-slide-text">
            <span className="news-slide-title">{s.title}</span>
            <span className="news-slide-caption">{s.caption}</span>
          </div>
        </div>
      ))}
      <div className="news-slider-bars">
        {SLIDES.map((_, i) => (
          <div key={i} className="news-slider-bar" onClick={() => go(i)}>
            <div
              key={`${i}-${tick}`}
              className={`news-slider-fill ${i < index ? "done" : i === index ? "running" : ""}`}
              style={i === index ? { animationDuration: `${DURATION_MS}ms` } : undefined}
            />
          </div>
        ))}
      </div>
    </div>
  );
}

export default NewsSlider;
