import { create } from "zustand";
import { persist } from "zustand/middleware";

type Locale = "en-GB" | "de";

interface SettingsState {
  locale: Locale;
  animatedBg: boolean;
  soundtrack: string | null;
  soundtrackChosen: boolean;
  musicVolume: number;
  setLocale: (locale: Locale) => void;
  setAnimatedBg: (enabled: boolean) => void;
  setSoundtrack: (id: string | null) => void;
  setSoundtrackChosen: (v: boolean) => void;
  setMusicVolume: (v: number) => void;
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      locale: "en-GB",
      animatedBg: true,
      soundtrack: null,
      soundtrackChosen: false,
      musicVolume: 0.35,
      setLocale: (locale) => set({ locale }),
      setAnimatedBg: (animatedBg) => set({ animatedBg }),
      setSoundtrack: (soundtrack) => set({ soundtrack }),
      setSoundtrackChosen: (soundtrackChosen) => set({ soundtrackChosen }),
      setMusicVolume: (musicVolume) => set({ musicVolume: Math.max(0, Math.min(1, musicVolume)) }),
    }),
    { name: "arc-settings" }
  )
);
