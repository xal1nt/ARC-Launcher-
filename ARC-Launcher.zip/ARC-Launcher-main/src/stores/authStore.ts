import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { LaunchCreds } from "../api/launcherService";

interface AuthState {
  creds: LaunchCreds | null;
  remember: boolean;
  discordName: string | null;
  avatarUrl: string | null;
  skinUrl: string | null;
  vbucks: number;
  setCreds: (creds: LaunchCreds, remember: boolean) => void;
  setProfile: (p: { discordName?: string | null; avatarUrl?: string | null; skinUrl?: string | null; vbucks?: number }) => void;
  signOut: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      creds: null,
      remember: false,
      discordName: null,
      avatarUrl: null,
      skinUrl: null,
      vbucks: 0,
      setCreds: (creds, remember) => set({ creds, remember }),
      setProfile: (p) =>
        set((s) => {
          const next: any = { ...s };
          for (const [k, v] of Object.entries(p)) if (v !== undefined) next[k] = v;
          return next;
        }),
      signOut: () => set({ creds: null, remember: false, discordName: null, avatarUrl: null, skinUrl: null, vbucks: 0 }),
    }),
    {
      name: "arc-auth",

      partialize: (s) => (s.remember ? s : { ...s, creds: null }),
    }
  )
);
