import { useState, useEffect, useRef } from "react";
import Titlebar from "./components/Titlebar";
import Navbar from "./components/Navbar";
import QuickLaunch from "./components/QuickLaunch";
import Starry from "./components/Starry";
import Splash from "./components/Splash";
import Maintenance from "./components/Maintenance";
import Login from "./components/Login";
import Onboarding, { type OnboardingInfo } from "./components/Onboarding";
import { useSoundtrack } from "./hooks/useSoundtrack";
import Home from "./pages/Home";
import Library from "./pages/Library";
import Shop from "./pages/Shop";
import Casino from "./pages/Casino";
import Servers from "./pages/Servers";
import TesterPrompt from "./components/TesterPrompt";
import Trading from "./pages/Trading";
import Settings from "./pages/Settings";
import {
  connectStream,
  validateSession,
  getMe,
  getActiveSkin,
  getVbucks,
  type LaunchCreds,
} from "./api/launcherService";
import { useLauncherStream } from "./hooks/useLauncherStream";
import { useSettingsStore } from "./stores/settingsStore";
import { useAuthStore } from "./stores/authStore";
import { t } from "./i18n";
import { invoke } from "@tauri-apps/api/core";
import "./App.css";

export async function refreshProfile() {
  const { creds, setProfile } = useAuthStore.getState();
  if (!creds) return;
  const [me, skin, vb] = await Promise.all([
    getMe(creds.accountId).catch(() => null),
    getActiveSkin(creds.accountId).catch(() => null),
    getVbucks(creds.accountId).catch(() => null),
  ]);
  setProfile({
    discordName: me?.discordName ?? undefined,
    avatarUrl: me?.discordAvatarUrl ?? undefined,
    skinUrl: skin?.imageUrl ?? undefined,
    vbucks: vb?.vbucks ?? undefined,
  });
}

function App() {
  const [ready, setReady] = useState(false);
  const [signingIn, setSigningIn] = useState(false);
  const [page, setPage] = useState("home");
  const [kicked, setKicked] = useState(false);
  const [onboarding, setOnboarding] = useState<OnboardingInfo | null>(null);
  const { status } = useLauncherStream();
  const locale = useSettingsStore((s) => s.locale);
  const creds = useAuthStore((s) => s.creds);
  const setCreds = useAuthStore((s) => s.setCreds);
  const setProfile = useAuthStore((s) => s.setProfile);
  const signOut = useAuthStore((s) => s.signOut);
  const loggedIn = !!creds;
  const wasLoggedIn = useRef(false);
  const prevMaintenance = useRef(status.maintenance);

  useEffect(() => {
    connectStream();
    const timer = setTimeout(async () => {
      const stored = useAuthStore.getState().creds;
      if (stored) {
        setSigningIn(true);
        try {
          const ok = await validateSession(stored.accountId, stored.token);
          if (!ok.success) signOut();
          else await refreshProfile();
        } catch {
        }
        setSigningIn(false);
      }
      setReady(true);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (status.maintenance && wasLoggedIn.current) setKicked(true);
    if (prevMaintenance.current && !status.maintenance) setKicked(false);
    prevMaintenance.current = status.maintenance;
    wasLoggedIn.current = loggedIn;
  }, [status.maintenance, loggedIn]);

  useEffect(() => {
    if (!loggedIn) return;
    const h = window.setInterval(() => refreshProfile().catch(() => {}), 60000);
    return () => window.clearInterval(h);
  }, [loggedIn]);

  const skinUrl = useAuthStore((s) => s.skinUrl);
  useEffect(() => {
    if (!loggedIn) { invoke("rpc_clear").catch(() => {}); return; }
    let inGame = false;
    const push = () => invoke("rpc_update", { skinUrl: skinUrl ?? null, skinName: null, playerName: creds?.username ?? null, inGame }).catch(() => {});
    push();
    const h = window.setInterval(async () => {
      const running = await invoke<boolean>("is_fortnite_running").catch(() => false);
      if (running !== inGame) { inGame = running; push(); }
    }, 5000);
    const keep = window.setInterval(push, 60000);
    return () => { window.clearInterval(h); window.clearInterval(keep); };
  }, [loggedIn, skinUrl, creds?.username]);

  async function handleLogin(c: LaunchCreds, remember: boolean, profile: { discordName: string | null; avatarUrl: string | null }) {
    setSigningIn(true);
    setCreds(c, remember);
    setProfile({ discordName: profile.discordName, avatarUrl: profile.avatarUrl });
    await refreshProfile().catch(() => {});
    setSigningIn(false);

    const st = useAuthStore.getState();
    if (!useSettingsStore.getState().soundtrackChosen) {
      setOnboarding({ mode: "existing", discordName: st.discordName, avatar: st.avatarUrl });
    }
  }

  function handleNewPlayer(p: { state: string; discordName: string; avatar: string | null }) {
    setOnboarding({ mode: "new", state: p.state, discordName: p.discordName, avatar: p.avatar });
  }

  async function handleNewAccount(c: LaunchCreds) {
    setCreds(c, true);
    if (onboarding) setProfile({ discordName: onboarding.discordName, avatarUrl: onboarding.avatar });
    await refreshProfile().catch(() => {});
  }

  const showApp = ready && !status.maintenance && loggedIn && !signingIn && !onboarding;
  useSoundtrack(showApp);

  return (
    <>
      <Starry />
      <Titlebar page={showApp ? page : undefined} />
      {!ready && <Splash />}
      {ready && status.maintenance && (
        <Maintenance status={status} kicked={kicked} onDismissKicked={() => setKicked(false)} />
      )}
      {ready && !status.maintenance && !loggedIn && !signingIn && !onboarding && (
        <Login onLogin={handleLogin} onNewPlayer={handleNewPlayer} />
      )}
      {ready && !status.maintenance && onboarding && !signingIn && (
        <Onboarding
          info={onboarding}
          onAccount={handleNewAccount}
          onDone={() => setOnboarding(null)}
          onCancel={() => { setOnboarding(null); signOut(); }}
        />
      )}
      {ready && !status.maintenance && signingIn && (
        <div className="signing-in">
          <div className="signing-in-spinner" />
          <span className="signing-in-text">{t("login.signing_in", locale)}</span>
        </div>
      )}
      {showApp && (
        <>
          <div className="top-bar">
            <Navbar page={page} setPage={setPage} onSignOut={signOut} />
            <QuickLaunch />
          </div>
          <TesterPrompt />
          <main className="container">
            {page === "home" && <Home />}
            {page === "library" && <Library />}
            {page === "shop" && <Shop />}
            {page === "servers" && <Servers />}
            {page === "casino" && <Casino />}
            {page === "trading" && <Trading />}
            {page === "settings" && <Settings />}
          </main>
        </>
      )}
    </>
  );
}

export default App;
