import { useState, useEffect } from "react";
import { invoke } from "@tauri-apps/api/core";
import { useAuthStore } from "../stores/authStore";
import { useLibraryStore } from "../stores/libraryStore";

export function useLaunch() {
  const creds = useAuthStore((s) => s.creds);
  const installPath = useLibraryStore((s) => s.installPath);
  const [running, setRunning] = useState(false);
  const [launching, setLaunching] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const h = window.setInterval(() => {
      invoke<boolean>("is_fortnite_running").then(setRunning).catch(() => {});
    }, 2000);
    return () => window.clearInterval(h);
  }, []);

  async function launch() {
    if (!creds || !installPath || launching || running) return;
    setLaunching(true);
    setError(null);
    try {
      await invoke<number>("launch_build", {
        args: { fortnitePath: installPath, email: creds.email, password: creds.password, accountId: creds.accountId, bubble: false },
      });
      setRunning(true);
    } catch (e: any) {
      setError(typeof e === "string" ? e : e?.message || "Launch failed.");
    } finally {
      setLaunching(false);
      window.setTimeout(() => setError(null), 8000);
    }
  }

  async function close() {
    await invoke("close_fortnite").catch(() => {});
    setRunning(false);
  }

  return { launch, close, running, launching, error, canLaunch: !!creds && !!installPath };
}
