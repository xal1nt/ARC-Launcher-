import { useEffect, useRef } from "react";
import { useSettingsStore } from "../stores/settingsStore";
import { findSoundtrack } from "../soundtracks";

export function useSoundtrack(active: boolean) {
  const id = useSettingsStore((s) => s.soundtrack);
  const volume = useSettingsStore((s) => s.musicVolume);
  const audio = useRef<HTMLAudioElement | null>(null);
  const currentId = useRef<string | null>(null);

  useEffect(() => {
    const track = findSoundtrack(id);
    if (!active || !track?.src) {
      audio.current?.pause();
      return;
    }
    if (!audio.current || currentId.current !== track.id) {
      audio.current?.pause();
      const a = new Audio(track.src);
      a.loop = true;
      audio.current = a;
      currentId.current = track.id;
    }
    const a = audio.current;

    a.volume = 0;
    let v = 0;
    const fade = window.setInterval(() => {
      v = Math.min(useSettingsStore.getState().musicVolume, v + 0.02);
      a.volume = v;
      if (v >= useSettingsStore.getState().musicVolume) window.clearInterval(fade);
    }, 60);
    a.play().catch(() => {
      const retry = () => { a.play().catch(() => {}); window.removeEventListener("pointerdown", retry); };
      window.addEventListener("pointerdown", retry);
    });
  }, [active, id]);

  useEffect(() => {
    if (audio.current) audio.current.volume = volume;
  }, [volume]);

  useEffect(() => () => { audio.current?.pause(); }, []);
}
