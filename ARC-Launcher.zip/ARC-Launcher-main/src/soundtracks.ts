import christmasBusCover from "./assets/soundtracks/christmas-battle-bus.png";

export interface Soundtrack {
  id: string;
  name: string;
  subtitle: string;
  cover: string | null;
  src: string | null;
}

export const SOUNDTRACKS: Soundtrack[] = [
  {
    id: "christmas-battle-bus",
    name: "Christmas Battle Bus",
    subtitle: "The festive Battle Bus theme",
    cover: christmasBusCover,
    src: "/soundtracks/christmas-battle-bus.mp3",
  },
  {
    id: "none",
    name: "No music",
    subtitle: "Keep the launcher quiet",
    cover: null,
    src: null,
  },
];

export function findSoundtrack(id: string | null | undefined): Soundtrack | undefined {
  return SOUNDTRACKS.find((s) => s.id === id);
}
