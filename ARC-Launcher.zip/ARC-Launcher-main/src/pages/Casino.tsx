import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import vbuckIcon from "../assets/icons/v-buck.png";
import arcLogo from "../assets/arc-logo.png";
import {
  getCasinoConfig, getCasinoRecent, openCrate, coinflip,
  type CasinoConfig, type CasinoWin, type CrateInfo, type CratePrize, type ReelItem,
} from "../api/launcherService";
import { useAuthStore } from "../stores/authStore";
import { rarityColor, cosmeticId } from "../rarity";
import "./Casino.css";

const ITEM_W = 128;
const SPIN_MS = 6000;

function Casino() {
  const vbucks = useAuthStore((s) => s.vbucks);
  const setProfile = useAuthStore((s) => s.setProfile);
  const [tab, setTab] = useState<"crates" | "coinflip">("crates");
  const [config, setConfig] = useState<CasinoConfig | null>(null);
  const [recent, setRecent] = useState<CasinoWin[]>([]);
  const [error, setError] = useState<string | null>(null);

  async function loadRecent() {
    const r = await getCasinoRecent().catch(() => null);
    if (r) setRecent(r.wins);
  }

  useEffect(() => {
    getCasinoConfig().then(setConfig).catch(() => setError("Couldn't reach the casino."));
    loadRecent();
    const h = window.setInterval(loadRecent, 20000);
    return () => window.clearInterval(h);
  }, []);

  function flash(msg: string) {
    setError(msg);
    window.setTimeout(() => setError(null), 3500);
  }

  return (
    <div className="page casino">
      <div className="casino-main">
        <div className="casino-head">
          <h1 className="casino-title">Casino</h1>
          <div className="casino-tabs">
            <button className={tab === "crates" ? "active" : ""} onClick={() => setTab("crates")}>Crates</button>
            <button className={tab === "coinflip" ? "active" : ""} onClick={() => setTab("coinflip")}>Coinflip</button>
          </div>
          <div className="casino-balance">
            <img src={vbuckIcon} alt="" />
            <span>{vbucks.toLocaleString()}</span>
          </div>
        </div>

        {!config && !error && <div className="casino-empty"><div className="article-spinner" /></div>}
        {config && !config.enabled && <div className="casino-empty">The casino is closed right now.</div>}
        {config?.enabled && tab === "crates" && (
          <Crates config={config} vbucks={vbucks} onBalance={(v) => setProfile({ vbucks: v })} onError={flash} onWin={loadRecent} />
        )}
        {config?.enabled && tab === "coinflip" && (
          <Coinflip config={config} vbucks={vbucks} onBalance={(v) => setProfile({ vbucks: v })} onError={flash} onWin={loadRecent} />
        )}
        <div className="casino-foot">For fun only. V-Bucks here are in-game currency with no cash value.</div>
      </div>

      <aside className="casino-feed">
        <div className="casino-feed-title">Recent wins</div>
        {recent.length === 0 && <div className="casino-feed-empty">No big wins yet. Be the first.</div>}
        {recent.map((w, i) => (
          <div key={i} className="casino-feed-row" style={{ borderLeftColor: rarityColor(w.rarity) }}>
            <img src={w.image} alt="" />
            <div className="casino-feed-text">
              <span className="casino-feed-user">{w.username}</span>
              <span className="casino-feed-label" style={{ color: rarityColor(w.rarity) }}>{w.label}</span>
              {w.templateId && <span className="cid">{cosmeticId(w.templateId)}</span>}
            </div>
            <span className="casino-feed-game">{w.game}</span>
          </div>
        ))}
      </aside>

      {error && <div className="shop-notice">{error}</div>}
    </div>
  );
}

interface GameProps {
  config: CasinoConfig;
  vbucks: number;
  onBalance: (v: number) => void;
  onError: (msg: string) => void;
  onWin: () => void;
}

function Crates({ config, vbucks, onBalance, onError, onWin }: GameProps) {
  const [opening, setOpening] = useState<CrateInfo | null>(null);
  const [reel, setReel] = useState<ReelItem[]>([]);
  const [offset, setOffset] = useState(0);
  const [animate, setAnimate] = useState(false);
  const [prize, setPrize] = useState<CratePrize | null>(null);
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const viewRef = useRef<HTMLDivElement>(null);
  const pending = useRef<{ prize: CratePrize; vbucks: number } | null>(null);

  async function open(crate: CrateInfo) {
    if (busy) return;
    if (vbucks < crate.price) { onError(`You need ${crate.price.toLocaleString()} V-Bucks for this crate.`); return; }
    setBusy(true);
    setOpening(crate);
    setDone(false);
    setPrize(null);
    setAnimate(false);
    setOffset(0);
    setReel(crate.preview.length ? Array.from({ length: 12 }, (_, i) => crate.preview[i % crate.preview.length]) : []);
    try {
      const r = await openCrate(crate.id);
      pending.current = { prize: r.prize, vbucks: r.vbucks };
      onBalance(r.vbucks - (r.prize.kind === "cosmetic" ? 0 : r.prize.amount || 0));
      setReel(r.reel);
      const viewW = viewRef.current?.clientWidth || 720;
      const jitter = Math.floor(Math.random() * 80) - 40;
      const target = r.winIndex * ITEM_W + 60 - viewW / 2 + jitter;
      requestAnimationFrame(() => requestAnimationFrame(() => { setAnimate(true); setOffset(target); }));
      window.setTimeout(() => {
        setPrize(r.prize);
        setDone(true);
        setBusy(false);
        if (pending.current) onBalance(pending.current.vbucks);
        onWin();
      }, SPIN_MS + 250);
    } catch (e: any) {
      setOpening(null);
      setBusy(false);
      onError(e?.message || "Couldn't open the crate.");
    }
  }

  function close() {
    if (busy) return;
    setOpening(null);
    setPrize(null);
  }

  return (
    <>
      <div className="crate-grid">
        {config.crates.map((c) => (
          <div key={c.id} className="crate-card" style={{ borderColor: c.color + "66", background: `radial-gradient(circle at 50% 20%, ${c.color}33, #0a0a0a 70%)` }}>
            <div className="crate-art">
              {c.preview.slice(0, 3).map((p, i) => (
                <img key={i} src={p.image} alt="" className={`crate-art-${i}`} style={{ filter: `drop-shadow(0 0 12px ${rarityColor(p.rarity)}88)` }} />
              ))}
            </div>
            <div className="crate-name">{c.name}</div>
            <div className="crate-sub">{c.count.toLocaleString()} items · Season 1–{c.seasonCap ?? 4}</div>
            <div className="crate-odds">
              {Object.entries(c.odds).map(([r, pct]) => (
                <span key={r} style={{ color: rarityColor(r) }} title={r}>{r === "vbucks" ? "V-Bucks" : r[0].toUpperCase() + r.slice(1)} {pct}%</span>
              ))}
            </div>
            <button className="crate-open" style={{ background: c.color }} disabled={busy || vbucks < c.price} onClick={() => open(c)}>
              <img src={vbuckIcon} alt="" /> {c.price.toLocaleString()}
            </button>
          </div>
        ))}
      </div>

      {opening && createPortal(
        <div className="modal-overlay crate-overlay" onClick={close}>
          <div className="crate-modal" onClick={(e) => e.stopPropagation()}>
            <div className="crate-modal-title">{opening.name}</div>
            <div className="reel-view" ref={viewRef}>
              <div className="reel-marker" />
              <div
                className="reel-strip"
                style={{
                  transform: `translateX(${-offset}px)`,
                  transition: animate ? `transform ${SPIN_MS}ms cubic-bezier(0.1, 0.75, 0.15, 1)` : "none",
                }}
              >
                {reel.map((it, i) => (
                  <div key={i} className="reel-item" style={{ borderBottomColor: rarityColor(it.rarity), background: `linear-gradient(180deg, ${rarityColor(it.rarity)}22, #0d0d0d)` }}>
                    <img src={it.image} alt="" />
                    <span>{it.name}</span>
                    {it.templateId && <span className="cid">{cosmeticId(it.templateId)}</span>}
                  </div>
                ))}
              </div>
            </div>

            <div className={`crate-result ${done ? "show" : ""}`}>
              {prize && (
                <>
                  <img src={prize.image} alt="" style={{ filter: `drop-shadow(0 0 24px ${rarityColor(prize.rarity)})` }} />
                  <div className="crate-result-text">
                    <span className="crate-result-kicker" style={{ color: rarityColor(prize.rarity) }}>
                      {prize.kind === "cosmetic" ? `${prize.rarity} ${prize.type || ""}` : prize.kind === "duplicate" ? "duplicate" : "V-Bucks"}
                    </span>
                    <span className="crate-result-name">{prize.name}</span>
                    {prize.templateId && (
                      <span className="crate-result-id">
                        <span className="cid">{prize.templateId}</span>
                        {prize.season && <span className="season-chip">{prize.season}</span>}
                      </span>
                    )}
                    {prize.kind === "cosmetic" && <span className="crate-result-sub">Added to your locker.</span>}
                  </div>
                </>
              )}
            </div>

            <div className="modal-actions modal-actions-right">
              <button className="modal-btn-text" disabled={busy} onClick={close}>Close</button>
              <button className="modal-btn modal-btn-sm" disabled={busy || vbucks < opening.price} onClick={() => open(opening)}>
                {busy ? "Opening…" : `Open another · ${opening.price.toLocaleString()}`}
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </>
  );
}

function Coinflip({ config, vbucks, onBalance, onError, onWin }: GameProps) {
  const { min, max } = config.coinflip;
  const [bet, setBet] = useState(String(Math.min(100, Math.max(min, vbucks)) || min));
  const [side, setSide] = useState<"heads" | "tails">("heads");
  const [rot, setRot] = useState(0);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ won: boolean; payout: number; bet: number } | null>(null);

  const amount = Math.floor(Number(bet) || 0);
  const cap = Math.min(max, vbucks);
  const set = (n: number) => setBet(String(Math.max(min, Math.min(cap, Math.floor(n)))));

  async function flip() {
    if (busy) return;
    if (amount < min || amount > max) { onError(`Bet between ${min} and ${max.toLocaleString()} V-Bucks.`); return; }
    if (amount > vbucks) { onError("Not enough V-Bucks."); return; }
    setBusy(true);
    setResult(null);
    try {
      const r = await coinflip(amount, side);
      onBalance(vbucks - amount);
      const base = rot + 360 * 6;
      const land = base - (base % 360) + (r.result === "heads" ? 0 : 180);
      setRot(land);
      window.setTimeout(() => {
        setResult({ won: r.won, payout: r.payout, bet: amount });
        onBalance(r.vbucks);
        setBusy(false);
        if (r.won) onWin();
      }, 1700);
    } catch (e: any) {
      setBusy(false);
      onError(e?.message || "Flip failed.");
    }
  }

  return (
    <div className="flip">
      <div className="flip-stage">
        <div className="coin" style={{ transform: `rotateY(${rot}deg)` }}>
          <div className="coin-face coin-heads"><img src={arcLogo} alt="" /></div>
          <div className="coin-face coin-tails"><img src={vbuckIcon} alt="" /></div>
        </div>
        <div className={`flip-result ${result ? (result.won ? "won" : "lost") : ""}`}>
          {result ? (result.won ? `You won ${result.payout.toLocaleString()} V-Bucks!` : `Lost ${result.bet.toLocaleString()} V-Bucks`) : busy ? "Flipping…" : "Pick a side. Double or nothing."}
        </div>
      </div>

      <div className="flip-controls">
        <div className="flip-sides">
          <button className={side === "heads" ? "active" : ""} disabled={busy} onClick={() => setSide("heads")}>
            <img src={arcLogo} alt="" /> Heads
          </button>
          <button className={side === "tails" ? "active" : ""} disabled={busy} onClick={() => setSide("tails")}>
            <img src={vbuckIcon} alt="" /> Tails
          </button>
        </div>

        <div className="flip-bet">
          <img src={vbuckIcon} alt="" />
          <input
            value={bet}
            disabled={busy}
            onChange={(e) => setBet(e.target.value.replace(/[^0-9]/g, "").slice(0, 7))}
            onBlur={() => set(amount)}
          />
          <button disabled={busy} onClick={() => set(amount / 2)}>½</button>
          <button disabled={busy} onClick={() => set(amount * 2)}>2×</button>
          <button disabled={busy} onClick={() => set(cap)}>Max</button>
        </div>
        <div className="flip-hint">Win pays {(amount * 2).toLocaleString()} · min {min} · max {max.toLocaleString()}</div>

        <button className="flip-go" disabled={busy || amount < min || amount > vbucks} onClick={flip}>
          {busy ? "Flipping…" : "Flip"}
        </button>
      </div>
    </div>
  );
}

export default Casino;
