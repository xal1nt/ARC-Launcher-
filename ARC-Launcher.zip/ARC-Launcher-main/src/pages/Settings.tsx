import { useState, useRef, useEffect } from "react";
import { IoChevronDown } from "react-icons/io5";
import { useSettingsStore } from "../stores/settingsStore";
import { SOUNDTRACKS } from "../soundtracks";
import { t } from "../i18n";
import "./Settings.css";

const sections = ["app", "game"] as const;

const languages = [
  { value: "en-GB" as const, label: "English (UK)" },
  { value: "de" as const, label: "Deutsch (German)" },
];

function Settings() {
  const { locale, setLocale, animatedBg, setAnimatedBg, soundtrack, setSoundtrack, musicVolume, setMusicVolume } = useSettingsStore();
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const active = "app";

  const currentLabel = languages.find((l) => l.value === locale)?.label ?? "";

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  return (
    <div className="page settings">
      <div className="settings-sidebar">
        {sections.map((section) => (
          <div
            key={section}
            className={`settings-sidebar-item ${active === section ? "active" : ""}`}
          >
            {t(`settings.${section}`, locale)}
          </div>
        ))}
      </div>
      <div className="settings-content">
        <div className="settings-card">
          <div className="settings-card-header">
            <span className="settings-card-title">{t("settings.language", locale)}</span>
          </div>
          <div className="dropdown" ref={dropdownRef}>
            <div className="dropdown-trigger" onClick={() => setOpen(!open)}>
              <span>{currentLabel}</span>
              <IoChevronDown className={`dropdown-icon ${open ? "open" : ""}`} />
            </div>
            {open && (
              <div className="dropdown-menu">
                {languages.map((lang) => (
                  <div
                    key={lang.value}
                    className={`dropdown-item ${locale === lang.value ? "active" : ""}`}
                    onClick={() => {
                      setLocale(lang.value);
                      setOpen(false);
                    }}
                  >
                    {lang.label}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        <div className="settings-card">
          <div className="settings-card-header">
            <span className="settings-card-title">{t("settings.animated_bg", locale)}</span>
          </div>
          <label className="settings-toggle">
            <input
              type="checkbox"
              checked={animatedBg}
              onChange={(e) => setAnimatedBg(e.target.checked)}
            />
            <span className="settings-toggle-label">{t("settings.animated_bg_label", locale)}</span>
          </label>
        </div>
        <div className="settings-card">
          <div className="settings-card-header">
            <span className="settings-card-title">Launcher soundtrack</span>
          </div>
          <div className="settings-tracks">
            {SOUNDTRACKS.map((tr) => {
              const active = (soundtrack ?? "none") === tr.id;
              return (
                <button
                  key={tr.id}
                  className={`settings-track ${active ? "active" : ""}`}
                  onClick={() => setSoundtrack(tr.id === "none" ? null : tr.id)}
                >
                  {tr.cover ? <img src={tr.cover} alt="" /> : <span className="settings-track-blank" />}
                  <span>{tr.name}</span>
                </button>
              );
            })}
          </div>
          <label className="settings-volume">
            <span>Volume</span>
            <input
              type="range"
              min={0}
              max={100}
              value={Math.round(musicVolume * 100)}
              onChange={(e) => setMusicVolume(Number(e.target.value) / 100)}
            />
            <span>{Math.round(musicVolume * 100)}%</span>
          </label>
        </div>
      </div>
    </div>
  );
}

export default Settings;
