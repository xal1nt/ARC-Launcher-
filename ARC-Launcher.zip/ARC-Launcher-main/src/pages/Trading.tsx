import { useEffect, useMemo, useRef, useState } from "react";
import { IoSearch, IoClose } from "react-icons/io5";
import { HiArrowsRightLeft } from "react-icons/hi2";
import vbuckIcon from "../assets/icons/v-buck.png";
import {
  getTrades, getTradeLocker, searchPlayers, createTrade, tradeAction,
  type Trade, type Cosmetic, type TradePlayer,
} from "../api/launcherService";
import { useAuthStore } from "../stores/authStore";
import { refreshProfile } from "../App";
import { rarityColor, cosmeticId } from "../rarity";
import "./Casino.css";
import "./Trading.css";

type Tab = "inbox" | "sent" | "new" | "history";
const MAX_ITEMS = 10;

function timeLeft(iso: string) {
  const ms = new Date(iso).getTime() - Date.now();
  if (ms <= 0) return "expired";
  const h = Math.floor(ms / 3600000);
  return h >= 1 ? `${h}h left` : `${Math.max(1, Math.floor(ms / 60000))}m left`;
}

function Trading() {
  const [tab, setTab] = useState<Tab>("inbox");
  const [data, setData] = useState<{ incoming: Trade[]; outgoing: Trade[]; history: Trade[] } | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function load() {
    const r = await getTrades().catch((e) => { flash(e?.message || "Couldn't load trades."); return null; });
    if (r) setData(r);
  }
  function flash(m: string) {
    setNotice(m);
    window.setTimeout(() => setNotice(null), 4000);
  }

  useEffect(() => {
    load();
    const h = window.setInterval(load, 15000);
    return () => window.clearInterval(h);
  }, []);

  async function act(action: "accept" | "decline" | "cancel", t: Trade) {
    setBusyId(t.tradeId);
    try {
      await tradeAction(action, t.tradeId);
      flash(action === "accept" ? "Trade complete! Check your locker." : action === "decline" ? "Trade declined." : "Trade cancelled.");
      if (action === "accept") refreshProfile().catch(() => {});
    } catch (e: any) {
      flash(e?.message || "That didn't work.");
    }
    setBusyId(null);
    load();
  }

  const inc = data?.incoming.length || 0;

  return (
    <div className="page trading">
      <div className="casino-head">
        <h1 className="casino-title">Trading</h1>
        <div className="trade-tabs">
          <button className={tab === "inbox" ? "active" : ""} onClick={() => setTab("inbox")}>
            Inbox {inc > 0 && <span className="trade-count">{inc}</span>}
          </button>
          <button className={tab === "sent" ? "active" : ""} onClick={() => setTab("sent")}>Sent</button>
          <button className={tab === "new" ? "active" : ""} onClick={() => setTab("new")}>New trade</button>
          <button className={tab === "history" ? "active" : ""} onClick={() => setTab("history")}>History</button>
        </div>
      </div>

      <div className="trade-body">
        {!data && tab !== "new" && <div className="casino-empty"><div className="article-spinner" /></div>}
        {data && tab === "inbox" && (
          <TradeList list={data.incoming} empty="No offers right now." mine={false} busyId={busyId} onAct={act} />
        )}
        {data && tab === "sent" && (
          <TradeList list={data.outgoing} empty="You haven't sent any offers." mine busyId={busyId} onAct={act} />
        )}
        {data && tab === "history" && (
          <TradeList list={data.history} empty="No past trades." mine={null} busyId={busyId} onAct={act} />
        )}
        {tab === "new" && <NewTrade onSent={() => { flash("Offer sent!"); load(); setTab("sent"); }} onError={flash} />}
      </div>

      {notice && <div className="shop-notice">{notice}</div>}
    </div>
  );
}

function Tile({ it, selected, onClick, small }: { it: Cosmetic; selected?: boolean; onClick?: () => void; small?: boolean }) {
  const c = rarityColor(it.rarity);
  return (
    <div
      className={`tt ${small ? "tt-sm" : ""} ${selected ? "sel" : ""} ${onClick ? "click" : ""}`}
      style={{ borderBottomColor: c, background: `linear-gradient(180deg, ${c}26, #0d0d0d 75%)` }}
      onClick={onClick}
      title={`${it.name} · ${it.type}${it.season ? " · " + it.season : ""}\n${it.templateId}`}
    >
      {it.season && <span className="season-chip tt-season">{it.season}</span>}
      <img src={it.image} alt="" loading="lazy" />
      <span>{it.name}</span>
      <span className="cid">{cosmeticId(it.templateId)}</span>
    </div>
  );
}

function Side({ title, items, vbucks }: { title: string; items: Cosmetic[]; vbucks: number }) {
  return (
    <div className="tc-side">
      <div className="tc-side-title">{title}</div>
      <div className="tc-items">
        {items.map((it) => <Tile key={it.templateId} it={it} small />)}
        {vbucks > 0 && (
          <div className="tt tt-sm tt-vb">
            <img src={vbuckIcon} alt="" />
            <span>{vbucks.toLocaleString()}</span>
          </div>
        )}
        {!items.length && !vbucks && <div className="tc-nothing">Nothing</div>}
      </div>
    </div>
  );
}

function TradeList({ list, empty, mine, busyId, onAct }: {
  list: Trade[]; empty: string; mine: boolean | null; busyId: string | null;
  onAct: (a: "accept" | "decline" | "cancel", t: Trade) => void;
}) {
  const me = useAuthStore((s) => s.creds?.accountId);
  if (!list.length) return <div className="casino-empty">{empty}</div>;
  return (
    <div className="tc-list">
      {list.map((t) => {
        const iSent = t.fromId === me;
        const other = iSent ? t.toName : t.fromName;

        const getItems = iSent ? t.want : t.give;
        const getVb = iSent ? t.wantVbucks : t.giveVbucks;
        const giveItems = iSent ? t.give : t.want;
        const giveVb = iSent ? t.giveVbucks : t.wantVbucks;
        return (
          <div key={t.tradeId} className="tc">
            <div className="tc-head">
              <span className="tc-who">{iSent ? <>To <b>{other}</b></> : <>From <b>{other}</b></>}</span>
              {t.status === "pending"
                ? <span className="tc-time">{timeLeft(t.expiresAt)}</span>
                : <span className={`tc-status st-${t.status}`}>{t.status}</span>}
            </div>
            {t.message && <div className="tc-msg">“{t.message}”</div>}
            <div className="tc-sides">
              <Side title="You get" items={getItems} vbucks={getVb} />
              <HiArrowsRightLeft className="tc-arrow" />
              <Side title="You give" items={giveItems} vbucks={giveVb} />
            </div>
            {t.reason && <div className="tc-reason">{t.reason}</div>}
            {t.status === "pending" && mine === false && (
              <div className="tc-actions">
                <button className="modal-btn-text" disabled={busyId === t.tradeId} onClick={() => onAct("decline", t)}>Decline</button>
                <button className="modal-btn modal-btn-sm" disabled={busyId === t.tradeId} onClick={() => onAct("accept", t)}>
                  {busyId === t.tradeId ? "Trading…" : "Accept"}
                </button>
              </div>
            )}
            {t.status === "pending" && mine === true && (
              <div className="tc-actions">
                <button className="modal-btn-text" disabled={busyId === t.tradeId} onClick={() => onAct("cancel", t)}>Cancel offer</button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function Picker({ title, items, selected, toggle, vb, setVb, maxVb, filter, setFilter, loading }: {
  title: string; items: Cosmetic[]; selected: Set<string>; toggle: (id: string) => void;
  vb: string; setVb: (v: string) => void; maxVb?: number; filter: string; setFilter: (v: string) => void; loading: boolean;
}) {
  const shown = useMemo(() => {
    const f = filter.trim().toLowerCase();
    return f ? items.filter((i) => i.name.toLowerCase().includes(f) || i.type.toLowerCase().includes(f)
      || i.templateId.toLowerCase().includes(f) || (i.season || "").toLowerCase() === f) : items;
  }, [items, filter]);
  return (
    <div className="tp">
      <div className="tp-head">
        <span className="tp-title">{title}</span>
        <span className="tp-count">{selected.size}/{MAX_ITEMS}</span>
      </div>
      <div className="tp-tools">
        <div className="tp-search">
          <IoSearch />
          <input placeholder="Name, ID or C1S2…" value={filter} onChange={(e) => setFilter(e.target.value)} />
        </div>
        <div className="tp-vb">
          <img src={vbuckIcon} alt="" />
          <input
            placeholder="0"
            value={vb}
            onChange={(e) => setVb(e.target.value.replace(/[^0-9]/g, "").slice(0, 7))}
            onBlur={() => { if (maxVb !== undefined && Number(vb) > maxVb) setVb(String(maxVb)); }}
          />
        </div>
      </div>
      <div className="tp-grid">
        {loading && <div className="tc-nothing">Loading…</div>}
        {!loading && !shown.length && <div className="tc-nothing">No tradeable items.</div>}
        {shown.map((it) => (
          <Tile key={it.templateId} it={it} selected={selected.has(it.templateId)} onClick={() => toggle(it.templateId)} />
        ))}
      </div>
    </div>
  );
}

function NewTrade({ onSent, onError }: { onSent: () => void; onError: (m: string) => void }) {
  const myVbucks = useAuthStore((s) => s.vbucks);
  const [q, setQ] = useState("");
  const [results, setResults] = useState<TradePlayer[]>([]);
  const [target, setTarget] = useState<TradePlayer | null>(null);
  const [mine, setMine] = useState<Cosmetic[]>([]);
  const [theirs, setTheirs] = useState<Cosmetic[]>([]);
  const [loadingMine, setLoadingMine] = useState(true);
  const [loadingTheirs, setLoadingTheirs] = useState(false);
  const [give, setGive] = useState<Set<string>>(new Set());
  const [want, setWant] = useState<Set<string>>(new Set());
  const [giveVb, setGiveVb] = useState("");
  const [wantVb, setWantVb] = useState("");
  const [fMine, setFMine] = useState("");
  const [fTheirs, setFTheirs] = useState("");
  const [msg, setMsg] = useState("");
  const [sending, setSending] = useState(false);
  const debounce = useRef<number | null>(null);

  useEffect(() => {
    getTradeLocker().then((r) => setMine(r.items)).catch((e) => onError(e?.message || "Couldn't load your locker.")).finally(() => setLoadingMine(false));
  }, []);

  useEffect(() => {
    if (debounce.current) window.clearTimeout(debounce.current);
    if (target || q.trim().length < 2) { setResults([]); return; }
    debounce.current = window.setTimeout(() => {
      searchPlayers(q.trim()).then((r) => setResults(r.players)).catch(() => setResults([]));
    }, 250);
  }, [q, target]);

  function pick(p: TradePlayer) {
    setTarget(p);
    setQ(p.username);
    setResults([]);
    setWant(new Set());
    setTheirs([]);
    setLoadingTheirs(true);
    getTradeLocker(p.username).then((r) => setTheirs(r.items)).catch((e) => onError(e?.message || "Couldn't load their locker.")).finally(() => setLoadingTheirs(false));
  }

  function toggler(set: Set<string>, setter: (s: Set<string>) => void) {
    return (id: string) => {
      const n = new Set(set);
      if (n.has(id)) n.delete(id);
      else if (n.size < MAX_ITEMS) n.add(id);
      else return onError(`Max ${MAX_ITEMS} items per side.`);
      setter(n);
    };
  }

  const gv = Math.floor(Number(giveVb) || 0);
  const wv = Math.floor(Number(wantVb) || 0);
  const canSend = !!target && (give.size > 0 || gv > 0) && (want.size > 0 || wv > 0) && gv <= myVbucks && !sending;

  async function send() {
    if (!target) return;
    setSending(true);
    try {
      await createTrade({ to: target.username, give: [...give], giveVbucks: gv, want: [...want], wantVbucks: wv, message: msg });
      setGive(new Set()); setWant(new Set()); setGiveVb(""); setWantVb(""); setMsg("");
      onSent();
    } catch (e: any) {
      onError(e?.message || "Couldn't send the offer.");
    }
    setSending(false);
  }

  return (
    <div className="nt">
      <div className="nt-who">
        <div className="tp-search nt-search">
          <IoSearch />
          <input
            placeholder="Who do you want to trade with? Search a username…"
            value={q}
            onChange={(e) => { setQ(e.target.value); setTarget(null); }}
          />
          {target && <IoClose className="nt-clear" onClick={() => { setTarget(null); setQ(""); setTheirs([]); setWant(new Set()); }} />}
        </div>
        {results.length > 0 && (
          <div className="nt-results">
            {results.map((p) => (
              <div key={p.accountId} className="nt-result" onClick={() => pick(p)}>
                {p.avatar ? <img src={p.avatar} alt="" /> : <div className="nt-avatar" />}
                <span>{p.username}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="nt-pickers">
        <Picker
          title="You give" items={mine} selected={give} toggle={toggler(give, setGive)}
          vb={giveVb} setVb={setGiveVb} maxVb={myVbucks} filter={fMine} setFilter={setFMine} loading={loadingMine}
        />
        <Picker
          title={target ? `You get from ${target.username}` : "You get"} items={theirs} selected={want} toggle={toggler(want, setWant)}
          vb={wantVb} setVb={setWantVb} filter={fTheirs} setFilter={setFTheirs} loading={loadingTheirs}
        />
      </div>

      <div className="nt-bar">
        <span className="nt-sum">
          Giving <b>{give.size}</b> item{give.size === 1 ? "" : "s"}{gv > 0 && <> + <b>{gv.toLocaleString()}</b> V-Bucks</>}
          {" · "}
          Getting <b>{want.size}</b> item{want.size === 1 ? "" : "s"}{wv > 0 && <> + <b>{wv.toLocaleString()}</b> V-Bucks</>}
        </span>
        <input className="nt-msg" placeholder="Message (optional)" maxLength={140} value={msg} onChange={(e) => setMsg(e.target.value)} />
        <button className="flip-go nt-send" disabled={!canSend} onClick={send}>{sending ? "Sending…" : "Send offer"}</button>
      </div>
      {!target && <div className="nt-hint">Pick a player first. Items you trade away are removed from your locker (and unequipped) once they accept.</div>}
    </div>
  );
}

export default Trading;
