import { useEffect, useMemo, useState } from "react";
import { getServers, type LiveServer } from "../api/launcherService";
import "./Casino.css";
import "./Servers.css";

const MATCH_MIN = 24;

function clock(s: LiveServer, now: number) {
  if (s.status === "gameended") return "Restarting";
  if (s.status !== "gamestarted") return s.players > 0 ? "In lobby · bus soon" : "Waiting for players";
  if (!s.startedAt) return "In game";
  const mins = Math.max(0, Math.floor((now - new Date(s.startedAt).getTime()) / 60000));
  const left = MATCH_MIN - mins;
  return `${mins}m in · ${left > 2 ? `${left}m left` : "Ending soon"}`;
}

function progress(s: LiveServer, now: number) {
  if (s.status === "gamestarted" && s.startedAt) {
    return Math.min(1, (now - new Date(s.startedAt).getTime()) / (MATCH_MIN * 60000));
  }
  if (s.status === "online") return Math.min(1, s.players / Math.max(1, s.maxplayers));
  return 0;
}

function Card({ s, now }: { s: LiveServer; now: number }) {
  const started = s.status === "gamestarted";
  const bots = s.bots || 0;
  const count = Math.max(s.alive || 0, s.players + bots);
  const p = progress(s, now);
  return (
    <div className={`sv-card sv-${s.status}`}>
      {s.image ? <img className="sv-bg" src={s.image} alt="" draggable={false} /> : <div className="sv-bg sv-bg-empty" />}
      <div className="sv-shade" />
      <span className="sv-region">{s.region}</span>
      <div className="sv-foot">
        <div className="sv-text">
          <div className="sv-name">{s.name}</div>
          <div className="sv-sub">{clock(s, now)}</div>
        </div>
        {s.status !== "gameended" && (
          <div className="sv-count">
            <b>{count}</b>
            <span>{started ? "left" : "in lobby"}</span>
          </div>
        )}
      </div>
      <div className="sv-bar"><i style={{ width: `${p * 100}%` }} /></div>
    </div>
  );
}

function Servers() {
  const [list, setList] = useState<LiveServer[] | null>(null);
  const [failed, setFailed] = useState(false);
  const [region, setRegion] = useState("ALL");
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    let alive = true;
    const load = () =>
      getServers()
        .then((r) => { if (alive) { setList(r.servers || []); setFailed(false); } })
        .catch(() => alive && setFailed(true));
    load();
    const a = window.setInterval(load, 10000);
    const b = window.setInterval(() => setNow(Date.now()), 15000);
    return () => { alive = false; window.clearInterval(a); window.clearInterval(b); };
  }, []);

  const regions = useMemo(() => ["ALL", ...Array.from(new Set((list || []).map((s) => s.region))).sort()], [list]);
  const shown = (list || []).filter((s) => region === "ALL" || s.region === region);
  const playing = (list || []).reduce((n, s) => n + (s.players || 0), 0);

  return (
    <div className="page servers">
      <div className="casino-head">
        <h1 className="casino-title">Servers</h1>
        {regions.length > 2 && (
          <div className="trade-tabs">
            {regions.map((r) => (
              <button key={r} className={region === r ? "active" : ""} onClick={() => setRegion(r)}>
                {r === "ALL" ? "All" : r}
              </button>
            ))}
          </div>
        )}
        {list && <span className="sv-total">{playing} playing · {list.length} {list.length === 1 ? "server" : "servers"}</span>}
      </div>

      <div className="sv-body">
        {!list && !failed && <div className="casino-empty"><div className="article-spinner" /></div>}
        {failed && !list && <div className="sv-empty">Couldn't reach the backend.</div>}
        {list && shown.length === 0 && <div className="sv-empty">No servers up right now.</div>}
        {shown.length > 0 && (
          <div className="sv-grid">
            {shown.map((s) => <Card key={s.id || `${s.region}-${s.playlist}`} s={s} now={now} />)}
          </div>
        )}
      </div>
    </div>
  );
}

export default Servers;
