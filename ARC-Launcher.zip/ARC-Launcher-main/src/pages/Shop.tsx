import { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import { IoClose } from "react-icons/io5";
import vbuckIcon from "../assets/icons/v-buck.png";
import { getShop, getOwned, buyItem, type Shop as ShopData, type ShopItem } from "../api/launcherService";
import { useAuthStore } from "../stores/authStore";
import { refreshProfile } from "../App";
import "./Shop.css";

const RARITY_COLORS: Record<string, string> = {
  legendary: "#e9a133",
  epic: "#b347e8",
  rare: "#2f8cf0",
  uncommon: "#5ec34a",
  common: "#8a8a8a",
};

function Shop() {
  const accountId = useAuthStore((s) => s.creds?.accountId);
  const vbucks = useAuthStore((s) => s.vbucks);
  const [shop, setShop] = useState<ShopData | null>(null);
  const [owned, setOwned] = useState<Set<string>>(new Set());
  const [active, setActive] = useState(0);
  const [hovered, setHovered] = useState(false);
  const [displayBalance, setDisplayBalance] = useState(0);
  const [selected, setSelected] = useState<ShopItem | null>(null);
  const [buying, setBuying] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  async function load() {
    const [s, o] = await Promise.all([
      getShop().catch(() => null),
      accountId ? getOwned(accountId).catch(() => null) : Promise.resolve(null),
    ]);
    if (s) setShop(s);
    if (o?.owned) setOwned(new Set(o.owned.map((x) => x.toLowerCase())));
  }

  useEffect(() => {
    load();
    const h = window.setInterval(load, 5 * 60 * 1000);
    return () => window.clearInterval(h);
  }, [accountId]);

  useEffect(() => {
    if (vbucks === 0) { setDisplayBalance(0); return; }
    const steps = 20;
    const increment = vbucks / steps;
    let current = 0;
    const interval = setInterval(() => {
      current += increment;
      if (current >= vbucks) { setDisplayBalance(vbucks); clearInterval(interval); }
      else setDisplayBalance(Math.floor(current));
    }, 40);
    return () => clearInterval(interval);
  }, [vbucks]);

  const sections = [
    { id: "featured", name: "Featured", items: shop?.featured ?? [] },
    { id: "daily", name: "Daily", items: shop?.daily ?? [] },
  ].filter((s) => s.items.length > 0);

  function scrollToSection(index: number) {
    setActive(index);
    document.getElementById(`shop-section-${sections[index].id}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function handleScroll(e: React.UIEvent<HTMLDivElement>) {
    const container = e.currentTarget;
    let closest = 0, minDist = Infinity;
    sections.forEach((s, i) => {
      const el = document.getElementById(`shop-section-${s.id}`);
      if (!el) return;
      const dist = Math.abs(el.offsetTop - container.offsetTop - container.scrollTop);
      if (dist < minDist) { minDist = dist; closest = i; }
    });
    setActive(closest);
  }

  function isOwned(item: ShopItem) {
    const id = item.id.toLowerCase();
    return owned.has(id) || owned.has(item.grant.toLowerCase()) || owned.has(item.grant.split(":").pop()!.toLowerCase());
  }

  async function confirmBuy() {
    if (!selected || !accountId) return;
    setBuying(true);
    try {
      const res = await buyItem(accountId, selected.offerId || selected.grant);
      if (!res.ok) throw new Error(res.message || "Purchase failed.");
      setNotice(`${selected.name} is now in your locker!`);
      setSelected(null);
      await Promise.all([load(), refreshProfile()]);
    } catch (e: any) {
      setNotice(e?.message || "Purchase failed.");
    } finally {
      setBuying(false);
      window.setTimeout(() => setNotice(null), 4000);
    }
  }

  return (
    <div className="page shop">
      <div className="shop-balance">
        <img src={vbuckIcon} alt="" className="shop-balance-icon" />
        <span className="shop-balance-text">{displayBalance.toLocaleString()}</span>
      </div>
      {sections.length > 1 && (
        <div className={`shop-sidebar ${hovered ? "expanded" : ""}`} onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}>
          {!hovered ? (
            <div className="shop-dots">
              {sections.map((_, i) => <div key={i} className={`shop-dot ${i === active ? "active" : ""}`} onClick={() => scrollToSection(i)} />)}
            </div>
          ) : (
            <div className="shop-nav-list">
              {sections.map((s, i) => <div key={s.id} className={`shop-nav-item ${i === active ? "active" : ""}`} onClick={() => scrollToSection(i)}>{s.name}</div>)}
            </div>
          )}
        </div>
      )}
      <div className="shop-content" onScroll={handleScroll}>
        {!shop && <div className="shop-loading"><div className="article-spinner" /></div>}
        {shop && sections.length === 0 && <div className="shop-empty">The shop is empty right now — check back after the next rotation.</div>}
        {sections.map((section) => (
          <div key={section.id} id={`shop-section-${section.id}`} className="shop-section">
            <h2 className="shop-section-title">{section.name}</h2>
            <div className={`shop-grid ${section.id === "featured" ? "shop-grid-featured" : ""}`}>
              {section.items.map((item) => {
                const isSkin = item.type.toLowerCase().includes("outfit") || item.grant.toLowerCase().startsWith("athenacharacter");
                const has = isOwned(item);
                const color = RARITY_COLORS[item.rarity.toLowerCase()] || "#8a8a8a";
                return (
                  <div
                    key={item.offerId || item.id}
                    className={`shop-item ${isSkin ? "shop-item-skin" : ""} ${has ? "owned" : ""}`}
                    style={{ borderColor: color + "55", background: `linear-gradient(180deg, ${color}22, #0a0a0a 70%)` }}
                    onClick={() => !has && setSelected(item)}
                  >
                    {item.banner && <span className="shop-item-banner">{item.banner === "LimitedTime" ? "LIMITED TIME" : "NEW"}</span>}
                    <img src={item.image || item.icon} alt={item.name} className={`shop-item-image ${isSkin ? "skin" : ""}`} />
                    <div className="shop-item-info">
                      <span className="shop-item-name">{item.name}</span>
                      <div className="shop-item-price">
                        <img src={vbuckIcon} alt="" className="shop-item-vbuck" />
                        <span className="shop-item-price-text">{has ? "OWNED" : item.price === 0 ? "FREE" : item.price.toLocaleString()}</span>
                      </div>
                    </div>
                    <div className="shop-item-footer" style={{ background: color }}>
                      <span className="shop-item-footer-text">{item.type.toUpperCase()}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
      {notice && <div className="shop-notice">{notice}</div>}
      {selected && createPortal(
        <div className="modal-overlay" onClick={() => !buying && setSelected(null)}>
          <div className="modal shop-modal" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setSelected(null)}><IoClose /></button>
            <img className="shop-modal-image" src={selected.image || selected.icon} alt="" />
            <span className="modal-title">{selected.name}</span>
            <span className="modal-desc">{selected.description || selected.type}</span>
            <div className="shop-modal-price">
              <img src={vbuckIcon} alt="" />
              <span>{selected.price.toLocaleString()}</span>
              <span className="shop-modal-balance">· you have {vbucks.toLocaleString()}</span>
            </div>
            <div className="modal-actions modal-actions-right">
              <button className="modal-btn-text" onClick={() => setSelected(null)} disabled={buying}>Cancel</button>
              <button className="modal-btn modal-btn-sm" onClick={confirmBuy} disabled={buying || vbucks < selected.price}>
                {buying ? "Buying…" : vbucks < selected.price ? "Not enough V-Bucks" : "Buy"}
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}

export default Shop;
